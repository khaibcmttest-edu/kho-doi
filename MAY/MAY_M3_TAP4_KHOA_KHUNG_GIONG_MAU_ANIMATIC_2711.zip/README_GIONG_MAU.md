# MÙA 3 TẬP 4 — GIỌNG MẪU (khóa khung bước b) + ANIMATIC (bước c)
Tập 4 "CUỘC SỐNG VỢ CHỒNG MỚI CƯỚI ĐẦY TIẾNG CƯỜI" — Mây, 27/11/2026.
Mỗi nhân vật 1 câu mẫu = câu thoại đầu tiên của nhân vật đó trong Tập 4, lồng bằng VieNeu
theo Bảng giọng chuẩn toàn series (26/11), 48kHz, tốc độ đích ~15 ký tự/giây.

| # | Nhân vật | Giọng VieNeu | atempo bảng | Hiệu chỉnh | Tốc độ cuối |
|---|----------|--------------|-------------|------------|-------------|
| 01 | Ông Mặt Trời | Minh Triết | 0,814 | — | 15,9 |
| 02 | Giọt Nước Tí | Thái Sơn | 0,90 | — | 14,3 |
| 03 | Cá Nhỏ | Ngọc Huyền | 0,85 | — | 16,7 |
| 04 | Cáo Tuyết Bắc Cực | Kim Thanh | 0,85 | ×1,294 (hiệu dụng 1,1 — Kim Thanh đọc chậm tự nhiên) | 14,1 |
| 05 | Chim Cánh Cụt con | Mai Anh | 0,85 | — | 14,8 |
| 06 | Sơn Dương con | Thiện Minh | 0,85 | — | 16,7 |
| 07 | Lạc Đà Llama | Thái Sơn | 0,85 | — | 14,7 |
| 08 | Ngựa con | Xuân Vĩnh | 0,90 | ×0,82 (hiệu dụng 0,738) | 15,6 |
| 09 | Lạc Đà con | Thiền Tâm Đức | 0,80 | ×1,375 (hiệu dụng 1,1) | 13,8 |
| 10 | Khỉ con | Adam bựa | 0,90 | — | 15,5 |
| 11 | Ếch Cây Mắt Đỏ | Minh Đức | 0,85 | — | 13,5 |
| 12 | Hoa Tulip | Ngọc Linh | 0,85 | — | 15,3 |
| 13 | Sâu Xanh | Đức Trí | 0,85 | ×1,294 (hiệu dụng 1,1) | 13,9 |
| 14 | Cá Hồi Hoa Anh Đào | Thùy Dung | 0,85 | ×0,843 (hiệu dụng 0,717) | 16,0 |
| 15 | Rùa Biển con | Thanh Bình | 0,80 | ×0,875 (hiệu dụng 0,7 — chạm sàn; xem ghi chú) | 17,2 |
| 16 | Giun Đất | Thái Sơn | 0,95 | — | 15,2 |
| 17 | Bọ Cánh Cứng Cát | Thùy Dung | 0,739 | — | 15,4 |
| 18 | Cây Đước Ngập Mặn | Thục Đoan | 0,85 | — | 15,7 |
| 19 | Thỏ Ngọc | Đoan Trang | 0,85 | — | 15,4 |
| 20 | Cây Ô Liu Cổ Thụ | Phạm Tuyên | 0,80 | — | 15,6 |
| 21 | Chị Lá | Thùy Dung | 0,739 | — | 16,4 |
| 22 | Bác Rễ | Adam | 0,794 | — | 14,6 |
| 23 | Thầy Hồ Tấn Khải | Thái Sơn | 0,95 | — | 15,8 |

Ghi chú:
- Robot Thám Hiểm + Tia Nắng Vàng chỉ xuất hiện hình trong Tập 4, không có thoại nên không có giọng mẫu.
- Rùa Biển con (15): câu duy nhất trong tập là câu nói chậm có dấu "..." ("Chỉ... cần... Cá... Hồi..."). Mẫu đã chỉnh tới sàn hiệu dụng 0,7 mà vẫn 17,2 ký tự/s; khi thu thật sẽ tách câu tại các dấu "..." và chèn khoảng lặng 0,4s giữa các mảnh để nhịp nói chậm đúng kịch bản.
- Cá Nhỏ: MÀU CAM theo chốt của Thầy 06:26 ngày 27/11 (thay hồng đào cũ) — hình chuẩn trưởng thành cam đã có trong bộ của Mưa.
- Animatic: file MUA3_TAP4_ANIMATIC.md (10 cảnh, cảnh ăn tiền Cảnh 7, tổng ước 236s + thẻ kết 10s = 246s).
