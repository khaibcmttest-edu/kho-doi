# ANIMATIC — MÙA 3 TẬP 4: "CUỘC SỐNG VỢ CHỒNG MỚI CƯỚI ĐẦY TIẾNG CƯỜI" (tập kết mùa)

Khóa khung bước (c) — chờ Đạo diễn duyệt rồi mới dựng thật. Kịch bản: Kill, TAI_LIEU_CHUNG/KICH_BAN_MUA3_CUOI_NHAU_KILL.docx.
Hình chuẩn: bộ trưởng thành của Mưa đã duyệt (MUA_M3_TAP1_HINH_CHUAN_TRUONG_THANH_2711.zip, MD5 ecd411c8fd6553844d2367ca7b222289) — dùng chung, không vẽ lại.
Giọng: Bảng giọng chuẩn toàn series (26/11). Thoại thuần 3.118 ký tự / 30 câu. Cảnh ăn tiền: Cảnh 7.
Thời lượng đoạn = max(20s, thoại + 1,6s); thoại đặt trễ 0,8s; câu cách nhau 0,4s; tốc độ đọc ~15 ký tự/giây; atempo 0,7–1,1.
Tổng ước: 236,0s + thẻ kết 10s = 246,0s. Thumbnail: khung giữa Cảnh 7. Chữ ký PNG góc phải trên. Loudnorm 2 lượt I=-15,5.

## Cảnh 1 — Buổi sáng đầu tiên tại Xóm Tân Hôn Khu Vườn Kỳ Diệu

- 1. Prompt hình (EN): Sunny morning in the newly built cozy garden neighborhood with ten themed cottages as a warm radiant golden sun character with a gentle smile, scholarly glasses and a bright golden bowtie and a fluffy smiling white cloud character floating gently, wearing a tiny rainbow tiara and a soft white silk shawl smile down while a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie waters flowers outside his water-dome cottage beside a cute bright orange clownfish with thin white stripes along the back, big expressive eyes, wearing a tiny coral tiara, floating in a clear water bubble, 3D Pixar-style animation.

- 2. Hành động: Nắng mai chiếu xuống mười ngôi nhà nhỏ xinh xắn mang phong cách riêng của từng cặp đôi trong Khu Vườn Kỳ Diệu.

- 3. Lời thoại:

Ông Mặt Trời: Chào buổi sáng mười tổ ấm mới cưới của Khu Vườn Kỳ Diệu! Hôm nay là ngày đầu tiên các cháu bắt đầu cuộc sống vợ chồng son đấy!

Giọt Nước Tí: Dạ chào Ông Mặt Trời và Chị Mây! Tụi cháu vừa thức dậy và đang bắt tay vào dọn dẹp tổ ấm mới đây ạ!

- 4. Giọng đọc (VieNeu): Ông Mặt Trời (Minh Triết 0,814) + Giọt Nước Tí (Thái Sơn 0,90)

- 5. Ghi chú nhạc không bản quyền: Nhạc nền buổi sáng trong trẻo, vui tươi (nhạc AI không bản quyền).

## Cảnh 2 — Tổ ấm Thủy Cung & Băng Tuyết: Tí + Cá Nhỏ và Chim Cánh Cụt con + Cáo Tuyết Bắc Cực

- 1. Prompt hình (EN): At two neighboring cottages: a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie adjusts a clear floating water bubble around a cute bright orange clownfish with thin white stripes along the back, big expressive eyes, wearing a tiny coral tiara, floating in a clear water bubble in their garden patio, while next door a small cute fluffy Arctic fox character with thick pure-white winter fur, tiny blue knitted scarf, round black nose, big warm amber eyes, stubby paws knits a scarf beside a cute chubby baby penguin character with soft fluffy ALL-GREY head and back, NOT black adult penguin head, wearing a long sea-blue knitted scarf cooling a small ice-brick balcony, 3D Pixar-style animation.

- 2. Hành động: Giọt Nước Tí điều chỉnh độ mát cho bong bóng nước của Cá Nhỏ; Cáo Tuyết Bắc Cực đan khăn ấm còn Chim Cánh Cụt con tạo ban công băng mát lạnh.

- 3. Lời thoại:

Cá Nhỏ: Nhờ Tí giữ nhiệt độ nước luôn mát rượi như suối nguồn nên góc vườn nhà mình lúc nào cũng dễ chịu quá chừng!

Giọt Nước Tí: Vì sức khỏe của Cá Nhỏ là ưu tiên số một của mình mà, cân bằng nhiệt độ chuẩn không cần chỉnh luôn!

Cáo Tuyết Bắc Cực: Nhà mình cũng vậy nè, Chim Cánh Cụt con giữ góc sân mát lạnh còn mình pha trà ấm, hợp gu tuyệt đối!

Chim Cánh Cụt con: Hihi, ở cạnh Cáo Tuyết Bắc Cực là thấy ấm áp từ trong tim ra ngoài luôn!

- 4. Giọng đọc (VieNeu): Cá Nhỏ (Ngọc Huyền 0,85) + Giọt Nước Tí (Thái Sơn 0,90) + Cáo Tuyết Bắc Cực (Kim Thanh 0,85) + Chim Cánh Cụt con (Mai Anh 0,85)

- 5. Ghi chú nhạc không bản quyền: Nhạc nền ấm áp, dễ thương (nhạc AI không bản quyền).

## Cảnh 3 — Tổ ấm Cao Nguyên & Thảo Nguyên: Sơn Dương con + Lạc Đà Llama và Ngựa con + Lạc Đà con

- 1. Prompt hình (EN): On the rocky terrace cottage, a cute agile mountain goat kid character with tiny curved horns, sturdy hooves, wearing a wide cozy red knitted scarf and a cute fluffy white baby llama character with long ears and a gentle face arrange flower pots on high ledges, while on the sandy-grass cottage below, a cute energetic baby zebra character with clear black-and-white stripes, a fluffy mane, bright eyes and a smart striped necktie jogs in place beside a cute sandy-beige one-humped baby camel with a small brass bell at neck, long eyelashes and a desert scarf ringing its brass bell, 3D Pixar-style animation.

- 2. Hành động: Sơn Dương con và Lạc Đà Llama trang trí ban công tầng cao; Ngựa con tập chạy sáng còn Lạc Đà con lắc chuông cổ vũ.

- 3. Lời thoại:

Sơn Dương con: Ngôi nhà hai tầng trên mỏm đá này đúng chuẩn sở thích leo cao ngắm cảnh của hai vợ chồng mình luôn!

Lạc Đà Llama: Lại còn đón gió mát lồng lộng mỗi sáng nữa chứ, hai đứa mình ăn ý từng chi tiết nhỏ!

Ngựa con: Còn nhà mình thì sáng nào cũng khởi động bằng một vòng chạy quanh vườn theo tiếng chuông của Lạc Đà con!

Lạc Đà con: Leng keng! Chạy xong về uống nước sương mát là khỏe re cả ngày luôn Ngựa con ơi!

- 4. Giọng đọc (VieNeu): Sơn Dương con (Thiện Minh 0,85) + Lạc Đà Llama (Thái Sơn 0,85) + Ngựa con (Xuân Vĩnh 0,90) + Lạc Đà con (Thiền Tâm Đức 0,80)

- 5. Ghi chú nhạc không bản quyền: Nhạc nền vui nhộn, năng động (nhạc AI không bản quyền).

## Cảnh 4 — Tổ ấm Tán Rừng & Vườn Hoa: Khỉ con + Ếch Cây Mắt Đỏ và Sâu Xanh + Hoa Tulip

- 1. Prompt hình (EN): In a treehouse cottage, a cute playful brown baby monkey character with big bright eyes, a curly tail and a stylish leafy fedora hat hangs a hammock beside a cute green tree frog character with very big red eyes, blue-yellow flank markings and orange toe pads, while in a blossom cottage below, a cute plump green caterpillar character with big curious eyes, tiny yellow shoes and a cheerful yellow ribbon bow waters a cute tulip flower character with a red-pink tulip bloom head, green stem body and leaf arms with a tiny leaf cup, 3D Pixar-style animation.

- 2. Hành động: Khỉ con và Ếch Cây Mắt Đỏ mắc võng trên cành cây cao; Sâu Xanh chăm chỉ tưới nước cho vườn hoa của Hoa Tulip.

- 3. Lời thoại:

Khỉ con: Nhà trên cây có võng đung đưa thế này mới đúng gu cặp đôi rừng rậm tụi mình chứ Ếch Cây Mắt Đỏ nhỉ!

Ếch Cây Mắt Đỏ: Quá chuẩn luôn! Vừa thoáng mát vừa ngắm được cả xóm tân hôn từ trên cao!

Hoa Tulip: Cảm ơn ông xã Sâu Xanh sáng nào cũng dậy sớm tưới sương và dọn cỏ quanh nhà cho mình nhé!

Sâu Xanh: Chăm sóc cho Hoa Tulip luôn tươi tắn rạng rỡ là nhiệm vụ hạnh phúc nhất của mình mà, hihi!

- 4. Giọng đọc (VieNeu): Khỉ con (Adam bựa 0,90) + Ếch Cây Mắt Đỏ (Minh Đức 0,85) + Hoa Tulip (Ngọc Linh 0,85) + Sâu Xanh (Đức Trí 0,85)

- 5. Ghi chú nhạc không bản quyền: Nhạc nền tươi sáng, tinh nghịch (nhạc AI không bản quyền).

## Cảnh 5 — Tổ ấm Đại Dương, Đất Cát, Công Nghệ & Vũ Trụ: Rùa Biển con + Cá Hồi Hoa Anh Đào, Giun Đất + Bọ Cánh Cứng Cát, Robot Thám Hiểm + Cây Đước Ngập Mặn, Thỏ Ngọc + Tia Nắng Vàng

- 1. Prompt hình (EN): Split-view garden neighborhood showing a cute little sea turtle character with an ornate patterned turquoise-green shell and friendly flippers with a cute pink salmon character with cherry-blossom-pink scales swimming inside a water bubble by a lotus stream, a friendly pink earthworm character wearing tiny round glasses and a cute pink bowtie with a small cute round desert beetle character with glossy golden-sand carapace covered in tiny dew-collecting bumps, miniature aviator goggles on forehead, dark brown boots, carrying a tiny gourd water canteen, expressive big eyes tending a tiny garden plot, a cute small Mars rover robot character with solar panel wings, six wheels and a friendly camera head recharging solar wings beside a cute cheerful young mangrove sapling character with arched stilt roots as legs, glossy dark-green oval leaves, wearing a miniature Vietnamese conical hat (non la), bright friendly eyes, and a cute small white rabbit character with soft fluffy white fur, long upright ears with pink inner ears, big round dark-brown eyes, rosy cheeks, a small pink nose and a cheerful smile, wearing a thin gold necklace with a golden crescent-moon pendant and shiny silver boots decorated with white stars and crescent moons, with a small fluffy white tail dancing with a cute nimble sparkling golden star-sprite character made of warm sunlight with a bright cheerful face, glowing ribbon trails, and tiny golden boots, 3D Pixar-style animation.

- 2. Hành động: Bốn cặp đôi còn lại khoe góc tổ ấm sáng tạo: suối nhân tạo, vườn rau sạch, cảm biến độ ẩm tự động và dàn đèn sao lấp lánh.

- 3. Lời thoại:

Cá Hồi Hoa Anh Đào: Rùa Biển con thiết kế dòng suối nhỏ chảy quanh nhà êm dịu đến mức bơi cả ngày không chán!

Rùa Biển con: Chỉ... cần... Cá... Hồi... Hoa... Anh... Đào... vui... là... mình... thấy... xứng... đáng!

Giun Đất: Vườn rau hữu cơ của mình và Bọ Cánh Cứng Cát đã nảy mầm xanh mướt rồi nè cả xóm ơi!

Bọ Cánh Cứng Cát: Có hệ thống hứng sương tự động của mình nữa thì cây nào cũng lớn nhanh như thổi!

Cây Đước Ngập Mặn: Robot Thám Hiểm còn lập trình cảm biến đo độ ẩm đất giúp mình chăm sóc vườn cây tự động luôn đấy!

Thỏ Ngọc: Còn tụi mình treo xong dàn đèn sao lấp lánh chuẩn bị cho bữa tiệc tối tân gia chung rồi!

- 4. Giọng đọc (VieNeu): Cá Hồi Hoa Anh Đào (Thùy Dung 0,85) + Rùa Biển con (Thanh Bình 0,80) + Giun Đất (Thái Sơn 0,95) + Bọ Cánh Cứng Cát (Thùy Dung 0,739) + Cây Đước Ngập Mặn (Thục Đoan 0,85) + Thỏ Ngọc (Đoan Trang 0,85)

- 5. Ghi chú nhạc không bản quyền: Nhạc nền rộn ràng, ấm áp tình làng nghĩa xóm (nhạc AI không bản quyền).

## Cảnh 6 — Các vị trưởng bối đi thăm xóm tân hôn & Lời khen ngợi

- 1. Prompt hình (EN): a wise old brown tree-root character with longer silver-streaked root beard, round spectacles, kind eyes and earthy tendrils, a cute ancient olive tree character with a gnarled brown trunk, kind old face and silvery-green olive leaves, and a vibrant cheerful green leaf character with big expressive eyes, tiny arms and legs, wearing a white pomelo-blossom hairclip strolling happily along the garden path, admiring the ten tidy cottages and greeting the couples, 3D Pixar-style animation.

- 2. Hành động: Bác Rễ, Cây Ô Liu Cổ Thụ và Chị Lá đi dạo thăm từng ngôi nhà, trầm trồ khen ngợi sự khéo léo và hòa thuận của mười cặp vợ chồng trẻ.

- 3. Lời thoại:

Cây Ô Liu Cổ Thụ: Nhìn mười ngôi nhà nhỏ ngăn nắp, mỗi nhà một vẻ nhưng hòa quyện vào khu vườn chung mà ấm lòng quá!

Chị Lá: Các cặp đôi không chỉ hợp gu mà còn biết điều chỉnh thói quen để tôn trọng và chăm sóc cho nhau từng chút một!

Bác Rễ: Đó chính là bí quyết giữ gìn sự cân bằng và hạnh phúc bền lâu trong mọi tổ ấm đấy!

- 4. Giọng đọc (VieNeu): Cây Ô Liu Cổ Thụ (Phạm Tuyên 0,80) + Chị Lá (Thùy Dung 0,739) + Bác Rễ (Adam 0,794)

- 5. Ghi chú nhạc không bản quyền: Nhạc nền du dương, tình cảm (nhạc AI không bản quyền).

## Cảnh 7 — Cảnh ăn tiền: Bữa tiệc tối tân gia sum vầy của đủ 25 nhân vật dưới ánh trăng sao

- 1. Prompt hình (EN): Magical starry night celebration in the garden where all 25 characters gather around a glowing circular feast table lit by a cute small white rabbit character with soft fluffy white fur, long upright ears with pink inner ears, big round dark-brown eyes, rosy cheeks, a small pink nose and a cheerful smile, wearing a thin gold necklace with a golden crescent-moon pendant and shiny silver boots decorated with white stars and crescent moons, with a small fluffy white tail, a cute nimble sparkling golden star-sprite character made of warm sunlight with a bright cheerful face, glowing ribbon trails, and tiny golden boots, and a fluffy smiling white cloud character floating gently, wearing a tiny rainbow tiara and a soft white silk shawl, with all ten couples seated happily beside a wise old brown tree-root character with longer silver-streaked root beard, round spectacles, kind eyes and earthy tendrils, a cute ancient olive tree character with a gnarled brown trunk, kind old face and silvery-green olive leaves, a warm radiant golden sun character with a gentle smile, scholarly glasses and a bright golden bowtie, and a vibrant cheerful green leaf character with big expressive eyes, tiny arms and legs, wearing a white pomelo-blossom hairclip, 3D Pixar-style animation.

- 2. Hành động: Dưới bầu trời đêm lung linh ánh trăng của Thỏ Ngọc và ánh sáng ấm áp của Tia Nắng Vàng, cả 25 nhân vật quây quần bên bàn tiệc tân gia ấm cúng.

- 3. Lời thoại:

Giọt Nước Tí: Nâng ly chúc mừng mười tổ ấm mới cưới của Khu Vườn Kỳ Diệu! Hạnh phúc lớn nhất vẫn là có một mái ấm yêu thương để trở về!

Cá Nhỏ: Chúc cho tình bạn và tình yêu của đại gia đình hai mươi lăm thành viên chúng ta mãi bền chặt và rộn rã tiếng cười!

- 4. Giọng đọc (VieNeu): Giọt Nước Tí (Thái Sơn 0,90) + Cá Nhỏ (Ngọc Huyền 0,85)

- 5. Ghi chú nhạc không bản quyền: Nhạc nền giao hưởng nhẹ nhàng, ấm áp, vỡ òa hạnh phúc (nhạc AI không bản quyền).

## Cảnh 8 — Bài học Sinh học khép lại Mùa 3: Cân bằng nội môi & Thích nghi sinh thái

- 1. Prompt hình (EN): a wise old brown tree-root character with longer silver-streaked root beard, round spectacles, kind eyes and earthy tendrils and a warm radiant golden sun character with a gentle smile, scholarly glasses and a bright golden bowtie projecting a glowing 3D holographic diagram of homeostasis and ecological adaptation to a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie and the cheerful couples, 3D Pixar-style animation.

- 2. Hành động: Bác Rễ và Ông Mặt Trời đúc kết nhẹ nhàng bài học Sinh học 11 về cân bằng nội môi và thích nghi sinh thái qua cách các cặp đôi điều chỉnh cuộc sống chung.

- 3. Lời thoại:

Bác Rễ: Trong Sinh học, cơ thể sống luôn duy trì cân bằng nội môi để ổn định và phát triển trước mọi thay đổi của môi trường!

Ông Mặt Trời: Cuộc sống gia đình cũng vậy: biết điều chỉnh hài hòa, thấu hiểu và thích nghi cùng nhau sẽ giữ cho mái ấm luôn bình yên!

- 4. Giọng đọc (VieNeu): Bác Rễ (Adam 0,794) + Ông Mặt Trời (Minh Triết 0,814)

- 5. Ghi chú nhạc không bản quyền: Nhạc nền sâu lắng, truyền cảm hứng (nhạc AI không bản quyền).

## Cảnh 9 — Ghi chép trang cuối sổ tay Mùa 3 & Thông điệp yêu thương

- 1. Prompt hình (EN): a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie closing his glowing holographic Season 3 travel journal beside a cute bright orange clownfish with thin white stripes along the back, big expressive eyes, wearing a tiny coral tiara, floating in a clear water bubble in front of their cozy garden cottage, 3D Pixar-style animation.

- 2. Hành động: Giọt Nước Tí viết dòng tổng kết khép lại Mùa 3 vào cuốn sổ tay hành trình cùng Cá Nhỏ.

- 3. Lời thoại:

Giọt Nước Tí: Khép lại trang cuối Mùa Ba thật trọn vẹn! Yêu thương nằm ở sự thấu hiểu thói quen của nhau, nhường nhịn và tạo nên tổ ấm bình yên. Bài học Sinh học hôm nay: cân bằng và thích nghi hài hòa là nền tảng của mọi sự sống bền vững!

- 4. Giọng đọc (VieNeu): Giọt Nước Tí (Thái Sơn 0,90)

- 5. Ghi chú nhạc không bản quyền: Nhạc nền tổng kết nhẹ nhàng, ấm áp (nhạc AI không bản quyền).

## Cảnh 10 — Chào tạm biệt Mùa 3 trọn vẹn & Lời chúc chuẩn

- 1. Prompt hình (EN): All 25 characters standing together in front of the ten cozy garden cottages waving warmly at the viewer under a starry rainbow sky with the golden signature of Thay Ho Tan Khai, 3D Pixar-style animation.

- 2. Hành động: Tất cả 25 nhân vật đứng thành vòng cung trước xóm tân hôn Khu Vườn Kỳ Diệu vẫy tay chào khán giả, khép lại Mùa 3 viên mãn.

- 3. Lời thoại:

Giọt Nước Tí: Hành trình Mùa Ba của Giọt Nước Tí và đại gia đình Khu Vườn Kỳ Diệu đến đây là khép lại thật viên mãn rồi! Cảm ơn các bạn đã đồng hành suốt ba vòng phiêu lưu và bốn tập đám cưới rộn rã! Nhớ bấm đăng ký kênh và bật chuông đón chờ hành trình mới nhé!

Thầy Hồ Tấn Khải: Thầy Hồ Tấn Khải chúc các em học tốt!

- 4. Giọng đọc (VieNeu): Giọt Nước Tí (Thái Sơn 0,90) + Thầy Hồ Tấn Khải (Thái Sơn 0,95)

- 5. Ghi chú nhạc không bản quyền: Nhạc outro hoành tráng, ấm áp, tiếng chuông thông báo và chữ ký Thầy Hồ Tấn Khải (nhạc AI không bản quyền).
