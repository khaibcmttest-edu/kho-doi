# 10 hình tham khảo Tập 4 Mùa 3 — Antigravity

- Nguồn: Antigravity trên máy thầy Khải, vẽ ngày 27/11/2026 từ kịch bản Tập 4 Mùa 3 "Cuộc Sống Vợ Chồng Mới Cưới Đầy Tiếng Cười" của Kill.
- Vai trò: HÌNH THAM KHẢO BỐ CỤC TỪNG CẢNH (scene_01.jpg → scene_10.jpg tương ứng Cảnh 1 → Cảnh 10).
- Nhân vật vẫn theo BỘ TRƯỞNG THÀNH CỦA MƯA ĐÃ DUYỆT làm chuẩn duy nhất — không dùng hình Antigravity thay chuẩn nhân vật.
- Cảnh 6 (scene_06.jpg) có nhân vật người ở nền nhà — thầy đã xem và chốt "có người cũng ko sao đâu", giữ nguyên dùng được, không phải lỗi.
- Đạo diễn đã soi: Tí không đuôi, Cá Nhỏ cam, Thỏ Ngọc đủ vòng cổ + ủng bạc, Cảnh 7 tiệc đêm đủ 25 nhân vật.
