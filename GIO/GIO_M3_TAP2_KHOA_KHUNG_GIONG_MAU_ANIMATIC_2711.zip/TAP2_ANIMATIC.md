# ANIMATIC — Mùa 3 Tập 2: “Tất Bật Chuẩn Bị Đám Cưới Liên Hoàn”

**Series:** Giọt Nước Tí Phiêu Lưu Khắp Thế Giới — Mùa 3 “Cưới Nhau” (kịch bản Kill, đã nghiệm thu ĐẠT).
**Chủ đề chặng:** Phân công chuẩn bị lễ cưới & những sự cố hậu trường cười nghiêng ngả.
**Cảnh ăn tiền:** Cảnh 7 — Bức tranh 3D tổng duyệt lễ đường thiên nhiên kết hợp bốn yếu tố Đất – Nước – Rừng – Vũ Trụ của cả 25 nhân vật.
**Thông điệp (1 ý):** Khi mỗi người phát huy đúng thế mạnh và biết phối hợp nhịp nhàng, mọi công việc khó khăn đều trở thành niềm vui chung.
**Kiến thức Sinh học 12 lồng nhẹ:** Quan hệ hỗ trợ trong quần xã sinh vật — cộng sinh và hợp tác giúp tối ưu nguồn lực.
**Tổng thoại thuần:** 2.971 ký tự / 28 lượt thoại / 10 cảnh (đếm lại từ kịch bản, khớp kịch bản).
**Chuyển tiếp:** Tập 3 (Mùa 3) — “Đám Cưới Liên Hoàn Rộn Rã Tại Khu Vườn Kỳ Diệu”.

**Hình chuẩn nhân vật:** bộ “trưởng thành” 25/25 đã duyệt của Mưa (`hinh_chuan_truong_thanh/`, dùng chung cả đội, KHÔNG vẽ lại).
**Giọng mẫu:** 24 giọng đã tổng hợp tại `work/giong_mau/` (xem `GIONG_MAU_Tap2.md`) — mỗi nhân vật 1 câu mẫu = câu thoại đầu tiên trong tập.
**Thời lượng ước tính:** số ký tự thoại ÷ 15, tối thiểu 20 giây/cảnh (theo chuẩn đoạn của Mưa). Tổng 10 cảnh ≈ 216 giây (≈ 3 phút 36 giây, chưa tính thẻ kết 10 giây).

## Ghi chú chung (khóa khung — áp dụng cho mọi cảnh)

- Prompt hình EN lấy NGUYÊN VĂN từ kịch bản, thêm câu khóa ở cuối mỗi prompt: *“Absolutely no numbers, no digits, no text, no letters, no watermarks.”*
- **Cá Nhỏ MÀU CAM** ở mọi cảnh có Cá Nhỏ (C5, C9, C10) theo chốt của thầy 06:26 ngày 27/11 (“Nếu Cá Nhỏ màu cam thì sau này cho nó màu cam luôn”) — thay hẳn mô tả hồng đào 24/11 cho mọi tập vẽ mới; hình chuẩn CHUAN_1/CHUAN_2 hồng đào cũ KHÔNG dùng cho Mùa 3.
- **Rùa Biển con (Cảnh 5) và Ông Mặt Trời (Cảnh 1, 6, 7) chỉ xuất hiện trong hình, KHÔNG có thoại** ở Tập 2 — không làm giọng mẫu cho 2 nhân vật này.
- **Cảnh 10 — Tí và Thầy cùng giọng Thái Sơn, thoại kề nhau:** đặt khoảng nghỉ 0,35 giây giữa 2 lượt thoại (tiền lệ Vòng 3 Tập 4 Cảnh 9: Giun Đất + Tí cùng Thái Sơn), biến tông nhẹ nếu cần tách giọng. Thầy chỉ có tiếng (voice-over), không có hình trong prompt Cảnh 10 — giữ nguyên, không tự thêm hình Thầy.
- **Cảnh 7 — prompt không liệt kê đủ tên 25 nhân vật** (chỉ nêu rõ Ông Mặt Trời, Chị Mây, Thỏ Ngọc, Tia Nắng Vàng, Bác Rễ, Cây Ô Liu + câu “all 25 characters stand together”): keyframe toàn cảnh phải đối chiếu đủ 25 nhân vật theo danh sách kho nhân vật, không thêm/bớt/đổi nhân vật.
- Chuẩn cứng Mùa 3: mượt liên tục không cà giật; không tua lại/lặp khung; không đứng hình (kéo dài clip bằng làm chậm + trôi khung theo cách của Mưa); nhân vật nhép miệng thì phải có tiếng thoại khớp. Mỗi tập chỉ sửa 1 lần.

---

## Cảnh 1 — Tiếng còi báo thức buổi sáng của Tổng đạo diễn Chị Lá

**Thời lượng ước tính:** 229 ký tự ÷ 15 ≈ 15.3 giây → **20.0 giây** (tối thiểu 20 giây/cảnh).

**1. Prompt hình (EN) — nguyên văn kịch bản + câu khóa:**

> Early morning in the garden as a vibrant cheerful green leaf character with big expressive eyes, tiny arms and legs, wearing a white pomelo-blossom hairclip holds a glowing checklist clipboard, waking up a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie, a cute playful brown baby monkey character with big bright eyes, a curly tail and a stylish leafy fedora hat, and a cute plump green caterpillar character with big curious eyes, tiny yellow shoes and a cheerful yellow ribbon bow while a warm radiant golden sun character with a gentle smile, scholarly glasses and a bright golden bowtie rises brightly, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**2. Hành động:** Sáng tinh mơ, Chị Lá cầm danh sách phân công điểm danh cả 25 thành viên bắt tay vào ngày tổng lực chuẩn bị đám cưới liên hoàn.

**3. Lời thoại (nguyên văn — kèm giọng VieNeu + atempo bảng):**

- **Chị Lá** (Thùy Dung 0,739): “Dậy thôi cả đội ơi! Chỉ còn một ngày nữa là tới lễ cưới liên hoàn của mười cặp đôi rồi, từng tổ vào vị trí chuẩn bị ngay nào!”
- **Giọt Nước Tí** (Thái Sơn 0,90): “Có mặt ngay Chị Lá ơi! Hôm nay tụi mình sẽ biến Khu Vườn Kỳ Diệu thành lễ đường lộng lẫy nhất hành tinh!”

**4. Giọng đọc (VieNeu):** Chị Lá (Thùy Dung 0,739); Giọt Nước Tí (Thái Sơn 0,90)

**5. Ghi chú nhạc không bản quyền:** Nhạc nền buổi sáng rộn ràng, tươi vui (nhạc AI không bản quyền).

---

## Cảnh 2 — Tổ Kỹ Thuật Đất & Cát: Giun Đất, Bọ Cánh Cứng Cát, Robot Thám Hiểm, Cây Đước Ngập Mặn

**Thời lượng ước tính:** 354 ký tự ÷ 15 ≈ 23.6 giây → **23.6 giây** (tối thiểu 20 giây/cảnh).

**1. Prompt hình (EN) — nguyên văn kịch bản + câu khóa:**

> Preparing the garden aisle, a friendly pink earthworm character wearing tiny round glasses and a cute pink bowtie aerates the soil, a small cute round desert beetle character with glossy golden-sand carapace covered in tiny dew-collecting bumps, miniature aviator goggles on forehead, dark brown boots, carrying a tiny gourd water canteen, expressive big eyes aligns glowing dew lanterns, a cute small Mars rover robot character with solar panel wings, six wheels and a friendly camera head measures straight lines with a laser beam, and a cute cheerful young mangrove sapling character with arched stilt roots as legs, glossy dark-green oval leaves, wearing a miniature Vietnamese conical hat (non la), bright friendly eyes stabilizes the wooden arch posts, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**2. Hành động:** Robot Thám Hiểm đo đạc thẳng tắp từng milimet, Cây Đước Ngập Mặn giữ trụ cổng, Giun Đất xới đất trồng hoa và Bọ Cánh Cứng Cát xếp đèn sương.

**3. Lời thoại (nguyên văn — kèm giọng VieNeu + atempo bảng):**

- **Robot Thám Hiểm** (Quốc Tuấn 0,85): “Bíp bíp! Trục lễ đường căn chỉnh chuẩn xác nhờ sự hỗ trợ giữ trụ vững vàng của Cây Đước Ngập Mặn!”
- **Cây Đước Ngập Mặn** (Thục Đoan 0,85): “Có bộ rễ của mình bám đất thì gió bão cũng không lung lay nổi cổng hoa đâu Robot ơi!”
- **Bọ Cánh Cứng Cát** (Thùy Dung 0,739): “Còn mình và Giun Đất đã trồng xong hai hàng hoa dọc lối đi và đặt đèn sương lấp lánh rồi đây!”
- **Giun Đất** (Thái Sơn 0,95): “Đất tơi xốp đủ ẩm thế này thì sáng mai hoa sẽ nở bung rực rỡ đúng giờ lành luôn!”

**4. Giọng đọc (VieNeu):** Robot Thám Hiểm (Quốc Tuấn 0,85); Cây Đước Ngập Mặn (Thục Đoan 0,85); Bọ Cánh Cứng Cát (Thùy Dung 0,739); Giun Đất (Thái Sơn 0,95)

**5. Ghi chú nhạc không bản quyền:** Nhạc nền vui tươi, nhịp điệu lao động hăng say (nhạc AI không bản quyền).

---

## Cảnh 3 — Sự cố treo ngược biển chữ Hỷ của đội Rừng Xanh: Khỉ con, Ếch Cây Mắt Đỏ, Sâu Xanh, Hoa Tulip

**Thời lượng ước tính:** 377 ký tự ÷ 15 ≈ 25.1 giây → **25.1 giây** (tối thiểu 20 giây/cảnh).

**1. Prompt hình (EN) — nguyên văn kịch bản + câu khóa:**

> High up on the floral wedding arch, a cute playful brown baby monkey character with big bright eyes, a curly tail and a stylish leafy fedora hat hangs upside down accidentally holding a 'Song Hy' banner upside down while a cute green tree frog character with very big red eyes, blue-yellow flank markings and orange toe pads, a cute plump green caterpillar character with big curious eyes, tiny yellow shoes and a cheerful yellow ribbon bow, and a cute tulip flower character with a red-pink tulip bloom head, green stem body and leaf arms laugh and point from below, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**2. Hành động:** Khỉ con treo lộn ngược tấm biển Song Hỷ; Hoa Tulip và Sâu Xanh đứng dưới cười nghiêng ngả nhắc khéo.

**3. Lời thoại (nguyên văn — kèm giọng VieNeu + atempo bảng):**

- **Hoa Tulip** (Ngọc Linh 0,85): “Khỉ con ơi, bạn treo ngược đầu nên chữ Song Hỷ cũng lộn nhào theo bạn luôn rồi kìa, haha!”
- **Ếch Cây Mắt Đỏ** (Minh Đức 0,85): “Để mình nhảy lên đỡ cho Khỉ con xoay lại ngay, chứ để vậy khách mời phải trồng cây chuối mới đọc được mất!”
- **Khỉ con** (Adam bựa 0,90): “Hahaha, mình quen nhìn thế giới lộn ngược rồi nên thấy chữ nào cũng thuận mắt hết trơn!”
- **Sâu Xanh** (Đức Trí 0,85): “Còn mình và Hoa Tulip kết xong hai trăm vòng hoa tươi mà mình không cắn trộm cánh nào luôn nha!”

**4. Giọng đọc (VieNeu):** Hoa Tulip (Ngọc Linh 0,85); Ếch Cây Mắt Đỏ (Minh Đức 0,85); Khỉ con (Adam bựa 0,90); Sâu Xanh (Đức Trí 0,85)

**5. Ghi chú nhạc không bản quyền:** Nhạc nền hài hước, tinh nghịch (nhạc AI không bản quyền).

**⚠️ Ghi chú khóa khung Cảnh 3 — biển chữ Song Hỷ:** hình AI làm biển đỏ KHÔNG chữ (câu khóa “Absolutely no numbers, no digits, no text…” đã gắn cuối prompt); chữ “Song Hỷ” nếu cần thì ghép chữ thật ở khâu dựng (overlay/drawtext), KHÔNG để công cụ tự vẽ chữ.

---

## Cảnh 4 — Tổ Hậu Cần & Âm Nhạc: Ngựa con, Lạc Đà con, Sơn Dương con, Lạc Đà Llama

**Thời lượng ước tính:** 366 ký tự ÷ 15 ≈ 24.4 giây → **24.4 giây** (tối thiểu 20 giây/cảnh).

**1. Prompt hình (EN) — nguyên văn kịch bản + câu khóa:**

> Carrying flower baskets and tuning wedding bells, a cute energetic baby zebra character with clear black-and-white stripes, a fluffy mane, bright eyes and a smart striped necktie trots beside a cute sandy-beige one-humped baby camel with a small brass bell at neck, long eyelashes and a desert scarf while a cute agile mountain goat kid character with tiny curved horns, sturdy hooves, wearing a wide cozy red knitted scarf and a cute fluffy white baby llama character with long ears and a gentle face arrange high terrace seating, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**2. Hành động:** Ngựa con chạy đưa thiệp mời siêu tốc, Lạc Đà con luyện gõ chuông đồng theo nhịp nhạc cưới, Sơn Dương con và Lạc Đà Llama sắp xếp khán đài trên cao.

**3. Lời thoại (nguyên văn — kèm giọng VieNeu + atempo bảng):**

- **Ngựa con** (Xuân Vĩnh 0,90): “Mình vừa phát xong thiệp mời khắp khu vườn trong chớp mắt, giờ tới màn tập nhịp hành lễ cùng Lạc Đà con nhé!”
- **Lạc Đà con** (Thiền Tâm Đức 0,80): “Leng keng! Tiếng chuông đồng của mình vang chuẩn nhịp như chuông lễ hội luôn rồi nè!”
- **Sơn Dương con** (Thiện Minh 0,85): “Khán đài trên cao đã được mình và Lạc Đà Llama kê phẳng phiu, nhìn bao quát trọn vẹn lễ đường!”
- **Lạc Đà Llama** (Thái Sơn 0,85): “Không một góc khuất nào luôn, ngày mai cả nhà tha hồ ngắm mười cặp đôi tỏa sáng!”

**4. Giọng đọc (VieNeu):** Ngựa con (Xuân Vĩnh 0,90); Lạc Đà con (Thiền Tâm Đức 0,80); Sơn Dương con (Thiện Minh 0,85); Lạc Đà Llama (Thái Sơn 0,85)

**5. Ghi chú nhạc không bản quyền:** Nhạc nền rộn rã, tiếng chuông đồng ngân vang (nhạc AI không bản quyền).

---

## Cảnh 5 — Đội Băng Tuyết & Đại Dương tạo sân khấu pha lê nước: Cá Nhỏ, Rùa Biển con, Cá Hồi Hoa Anh Đào, Chim Cánh Cụt con, Cáo Tuyết Bắc Cực

**Thời lượng ước tính:** 344 ký tự ÷ 15 ≈ 22.9 giây → **22.9 giây** (tối thiểu 20 giây/cảnh).

**1. Prompt hình (EN) — nguyên văn kịch bản + câu khóa:**

> Around the central garden pond, a cute bright orange clownfish with thin white stripes along the back, big expressive eyes, wearing a tiny coral tiara, floating in a clear water bubble and a cute pink salmon character with cherry-blossom-pink scales swimming inside a water bubble blow shimmering water bubbles guided by a cute little sea turtle character with an ornate patterned turquoise-green shell and friendly flippers, while a cute chubby baby penguin character with soft fluffy ALL-GREY head and back, NOT black adult penguin head, wearing a long sea-blue knitted scarf and a small cute fluffy Arctic fox character with thick pure-white winter fur, tiny blue knitted scarf, round black nose, big warm amber eyes, stubby paws polish sparkling ice-crystal pedestals, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**2. Hành động:** Cá Nhỏ, Cá Hồi Hoa Anh Đào và Rùa Biển con thổi dải bong bóng nước; Chim Cánh Cụt con và Cáo Tuyết Bắc Cực tạo bệ băng pha lê phản chiếu ánh sáng.

**3. Lời thoại (nguyên văn — kèm giọng VieNeu + atempo bảng):**

- **Cá Nhỏ** (Ngọc Huyền 0,85): “Mình và Cá Hồi Hoa Anh Đào đã thổi xong dải bong bóng nước cầu vồng bay dọc lễ đường rồi nè!”
- **Cá Hồi Hoa Anh Đào** (Thùy Dung 0,85): “Nhờ Rùa Biển con điều tiết dòng nước êm dịu nên bong bóng nào cũng tròn xoe lung linh!”
- **Cáo Tuyết Bắc Cực** (Kim Thanh 0,85): “Còn mình và Chim Cánh Cụt con vừa tạo xong các trụ băng pha lê phản chiếu ánh sáng siêu đẹp!”
- **Chim Cánh Cụt con** (Mai Anh 0,85): “Nhìn bóng bẩy đến mức mình suýt trượt bụng lên thử độ trơn luôn đấy, hihi!”

**4. Giọng đọc (VieNeu):** Cá Nhỏ (Ngọc Huyền 0,85); Cá Hồi Hoa Anh Đào (Thùy Dung 0,85); Cáo Tuyết Bắc Cực (Kim Thanh 0,85); Chim Cánh Cụt con (Mai Anh 0,85)

**5. Ghi chú nhạc không bản quyền:** Nhạc nền trong trẻo, lấp lánh tiếng bong bóng nước (nhạc AI không bản quyền).

**⚠️ Ghi chú khóa khung Cảnh 5:** Cá Nhỏ MÀU CAM (chốt 27/11). Rùa Biển con chỉ xuất hiện trong hình (điều tiết dòng nước), KHÔNG có thoại.

---

## Cảnh 6 — Tổ Ánh Sáng & Bầu Trời thử hiệu ứng: Ông Mặt Trời, Chị Mây, Thỏ Ngọc, Tia Nắng Vàng

**Thời lượng ước tính:** 303 ký tự ÷ 15 ≈ 20.2 giây → **20.2 giây** (tối thiểu 20 giây/cảnh).

**1. Prompt hình (EN) — nguyên văn kịch bản + câu khóa:**

> In the sky above the garden, a warm radiant golden sun character with a gentle smile, scholarly glasses and a bright golden bowtie, a fluffy smiling white cloud character floating gently, wearing a tiny rainbow tiara and a soft white silk shawl, a cute small white rabbit character with soft fluffy white fur, long upright ears with pink inner ears, big round dark-brown eyes, rosy cheeks, a small pink nose and a cheerful smile, wearing a thin gold necklace with a golden crescent-moon pendant and shiny silver boots decorated with white stars and crescent moons, with a small fluffy white tail, and a cute nimble sparkling golden star-sprite character made of warm sunlight with a bright cheerful face, glowing ribbon trails, and tiny golden boots test rainbow sunbeams and silver moonlight sparkles over the wedding stage, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**2. Hành động:** Ông Mặt Trời và Tia Nắng Vàng chiếu tia nắng xuyên qua làn sương của Chị Mây, kết hợp ánh trăng bạc của Thỏ Ngọc tạo cầu vồng lung linh.

**3. Lời thoại (nguyên văn — kèm giọng VieNeu + atempo bảng):**

- **Thỏ Ngọc** (Đoan Trang 0,85): “Ánh trăng bạc của mình hòa cùng Tia Nắng Vàng và Chị Mây tạo vầng hào quang cầu vồng đẹp như mơ luôn!”
- **Tia Nắng Vàng** (Quỳnh Anh 0,85): “Ngày mai khi mười cặp đôi bước vào lễ đường, tụi mình sẽ bật hiệu ứng ánh sáng này rực rỡ nhất bầu trời!”
- **Chị Mây** (Mỹ Duyên 0,85): “Chị đã canh chuẩn lượng hơi nước rồi, đảm bảo cầu vồng hiện rõ mà không làm ướt nơ chú rể nào hết!”

**4. Giọng đọc (VieNeu):** Thỏ Ngọc (Đoan Trang 0,85); Tia Nắng Vàng (Quỳnh Anh 0,85); Chị Mây (Mỹ Duyên 0,85)

**5. Ghi chú nhạc không bản quyền:** Nhạc nền kỳ ảo, lung linh (nhạc AI không bản quyền).

**⚠️ Ghi chú khóa khung Cảnh 6:** Ông Mặt Trời chỉ xuất hiện trong hình, KHÔNG có thoại.

---

## Cảnh 7 — Cảnh ăn tiền: Tổng duyệt lễ đường thiên nhiên 3D hợp lực 25 thành viên

**Thời lượng ước tính:** 233 ký tự ÷ 15 ≈ 15.5 giây → **20.0 giây** (tối thiểu 20 giây/cảnh).

**1. Prompt hình (EN) — nguyên văn kịch bản + câu khóa:**

> Grand evening rehearsal in the illuminated magical garden where all 25 characters stand together admiring the completed nature wedding cathedral: glowing dew lanterns, floral arches, floating rainbow water bubbles, ice-crystal pedestals, and a shimmering rainbow canopy cast by a warm radiant golden sun character with a gentle smile, scholarly glasses and a bright golden bowtie, a fluffy smiling white cloud character floating gently, wearing a tiny rainbow tiara and a soft white silk shawl, a cute small white rabbit character with soft fluffy white fur, long upright ears with pink inner ears, big round dark-brown eyes, rosy cheeks, a small pink nose and a cheerful smile, wearing a thin gold necklace with a golden crescent-moon pendant and shiny silver boots decorated with white stars and crescent moons, with a small fluffy white tail, and a cute nimble sparkling golden star-sprite character made of warm sunlight with a bright cheerful face, glowing ribbon trails, and tiny golden boots, with a wise old brown tree-root character with longer silver-streaked root beard, round spectacles, kind eyes and earthy tendrils and a cute ancient olive tree character with a gnarled brown trunk, kind old face and silvery-green olive leaves beaming proudly, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**2. Hành động:** Tất cả 25 nhân vật bật sáng toàn bộ công trình lễ đường thiên nhiên: hoa nở rộ, đèn sương lung linh, bong bóng nước bay bổng dưới vòm cầu vồng.

**3. Lời thoại (nguyên văn — kèm giọng VieNeu + atempo bảng):**

- **Bác Rễ** (Adam 0,794): “Tuyệt tác! Khi hai mươi lăm thành viên cùng chung tay, Khu Vườn Kỳ Diệu đã hóa thành thánh đường thiên nhiên lộng lẫy nhất!”
- **Cây Ô Liu Cổ Thụ** (Phạm Tuyên 0,80): “Mỗi người một thế mạnh, phối hợp nhịp nhàng không chê vào đâu được, ngày mai chắc chắn sẽ là ngày vui lịch sử!”

**4. Giọng đọc (VieNeu):** Bác Rễ (Adam 0,794); Cây Ô Liu Cổ Thụ (Phạm Tuyên 0,80)

**5. Ghi chú nhạc không bản quyền:** Nhạc nền hoành tráng, ấm áp, vỡ òa tự hào (nhạc AI không bản quyền).

**⭐ Cảnh ăn tiền — ghi chú khóa khung Cảnh 7:** 1 keyframe toàn cảnh đủ 25 nhân vật làm hình chuẩn khóa khung. Khi dựng clip được tách 2 góc quay (toàn cảnh + cận nhóm) miễn đủ 25 nhân vật, không thêm/bớt/đổi nhân vật; cách tách cụ thể chốt ở bước animatic này khi Đạo diễn duyệt. Lễ đường gồm: đèn sương lung linh, cổng hoa, bong bóng nước cầu vồng bay bổng, bệ băng pha lê, vòm cầu vồng (bốn yếu tố Đất – Nước – Rừng – Vũ Trụ).

---

## Cảnh 8 — Bài học Sinh học từ buổi chuẩn bị: Quan hệ hỗ trợ trong quần xã sinh vật

**Thời lượng ước tính:** 271 ký tự ÷ 15 ≈ 18.1 giây → **20.0 giây** (tối thiểu 20 giây/cảnh).

**1. Prompt hình (EN) — nguyên văn kịch bản + câu khóa:**

> a wise old brown tree-root character with longer silver-streaked root beard, round spectacles, kind eyes and earthy tendrils and a vibrant cheerful green leaf character with big expressive eyes, tiny arms and legs, wearing a white pomelo-blossom hairclip showing a glowing 3D holographic diagram of mutualism and cooperation in ecosystems to a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie and the cheerful group, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**2. Hành động:** Bác Rễ và Chị Lá chỉ ra bí quyết thành công của buổi chuẩn bị: giống như quan hệ cộng sinh và hợp tác trong tự nhiên, các loài hỗ trợ nhau để cùng tỏa sáng.

**3. Lời thoại (nguyên văn — kèm giọng VieNeu + atempo bảng):**

- **Bác Rễ** (Adam 0,794): “Các cháu thấy không, giống như quan hệ hỗ trợ trong quần xã sinh vật, khi mỗi loài phát huy sở trường và hợp tác nhịp nhàng thì cả hệ sinh thái đều vững mạnh!”
- **Chị Lá** (Thùy Dung 0,739): “Và trong cuộc sống cũng vậy, biết sẻ chia và phối hợp đúng thế mạnh sẽ biến mọi việc khó thành niềm vui trọn vẹn!”

**4. Giọng đọc (VieNeu):** Bác Rễ (Adam 0,794); Chị Lá (Thùy Dung 0,739)

**5. Ghi chú nhạc không bản quyền:** Nhạc nền khám phá khoa học nhẹ nhàng (nhạc AI không bản quyền).

---

## Cảnh 9 — Ghi chép sổ tay trước giờ G & Thông điệp hợp tác

**Thời lượng ước tính:** 233 ký tự ÷ 15 ≈ 15.5 giây → **20.0 giây** (tối thiểu 20 giây/cảnh).

**1. Prompt hình (EN) — nguyên văn kịch bản + câu khóa:**

> a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie writing in his glowing holographic notebook beside a cute bright orange clownfish with thin white stripes along the back, big expressive eyes, wearing a tiny coral tiara, floating in a clear water bubble under the twinkling dew lanterns at night, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**2. Hành động:** Giọt Nước Tí ghi lại thông điệp phối hợp và kiến thức Sinh học 12 vào sổ tay trước đêm trọng đại.

**3. Lời thoại (nguyên văn — kèm giọng VieNeu + atempo bảng):**

- **Giọt Nước Tí** (Thái Sơn 0,90): “Sẵn sàng cho ngày mai rồi! Khi mỗi người phát huy đúng thế mạnh và phối hợp nhịp nhàng, mọi việc khó đều thành niềm vui chung. Bài học Sinh học hôm nay: quan hệ cộng sinh và hợp tác giúp các loài hỗ trợ nhau tạo nên quần xã bền vững!”

**4. Giọng đọc (VieNeu):** Giọt Nước Tí (Thái Sơn 0,90)

**5. Ghi chú nhạc không bản quyền:** Nhạc nền sâu lắng, ấm áp (nhạc AI không bản quyền).

**⚠️ Ghi chú khóa khung Cảnh 9:** Cá Nhỏ MÀU CAM (chốt 27/11). Tí ghi sổ tay — đoạn độc thoại dài nhất tập (233 ký tự, 1 lượt).

---

## Cảnh 10 — Hẹn gặp Tập 3 Đám Cưới Liên Hoàn & Lời chúc chuẩn

**Thời lượng ước tính:** 261 ký tự ÷ 15 ≈ 17.4 giây → **20.0 giây** (tối thiểu 20 giây/cảnh).

**1. Prompt hình (EN) — nguyên văn kịch bản + câu khóa:**

> a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie, a cute bright orange clownfish with thin white stripes along the back, big expressive eyes, wearing a tiny coral tiara, floating in a clear water bubble, and a cute ancient olive tree character with a gnarled brown trunk, kind old face and silvery-green olive leaves waving beside a glowing golden wedding invitation for Episode 3 and an open Biology 12 textbook icon, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**2. Hành động:** Giọt Nước Tí, Cá Nhỏ và cụ Cây Ô Liu Cổ Thụ giơ thiệp mời đám cưới liên hoàn, vẫy tay chào khán giả cùng lời chúc của Thầy Hồ Tấn Khải.

**3. Lời thoại (nguyên văn — kèm giọng VieNeu + atempo bảng):**

- **Giọt Nước Tí** (Thái Sơn 0,90): “Lễ đường đã lung linh ánh sáng rồi! Đón xem Tập 3 Mùa Ba: Đám Cưới Liên Hoàn Rộn Rã Tại Khu Vườn Kỳ Diệu để chứng kiến giây phút thiêng liêng của mười cặp đôi nhé! Nhớ mở sách Sinh học 12, bấm đăng ký kênh và bật chuông nha!”
- **Thầy Hồ Tấn Khải** (Thái Sơn 0,95): “Thầy Hồ Tấn Khải chúc các em học tốt!”

**4. Giọng đọc (VieNeu):** Giọt Nước Tí (Thái Sơn 0,90); Thầy Hồ Tấn Khải (Thái Sơn 0,95)

**5. Ghi chú nhạc không bản quyền:** Nhạc outro vui tươi, tiếng chuông thông báo và chữ ký Thầy Hồ Tấn Khải (nhạc AI không bản quyền).

**⚠️ Ghi chú khóa khung Cảnh 10:** Cá Nhỏ MÀU CAM (chốt 27/11). Tí (Thái Sơn 0,90) và Thầy (Thái Sơn 0,95) cùng giọng, thoại kề nhau — nghỉ 0,35 giây giữa 2 lượt; Thầy voice-over, không có hình trong prompt.

---

## Tổng kết thời lượng ước tính

Tổng 10 cảnh ≈ **216.3 giây (≈ 3.6 phút)** chưa tính thẻ kết 10 giây. So với các tập đã ĐẠT (Tập 7 v4: 242 giây; Tập 8 v2: 227 giây; Tập 4 Vòng 3: 230 giây), thời lượng dự kiến nằm trong khung quen thuộc — không cảnh nào vượt quá khả năng kéo dài bằng làm chậm + trôi khung. Ba cảnh dài nhất: Cảnh 3 (25,1 giây), Cảnh 4 (24,4 giây), Cảnh 2 (23,6 giây).

## Trạng thái khóa khung

- (a) Hình chuẩn “trưởng thành”: bộ 25/25 của Mưa ĐÃ DUYỆT, dùng chung cả đội.
- (b) Giọng mẫu: 24 giọng tại `work/giong_mau/` — chờ Đạo diễn nghe duyệt.
- (c) Animatic: file này — chờ Đạo diễn duyệt.
- Chưa dựng thật (không làm clip video, không ráp phim) cho tới khi Đạo diễn duyệt đủ 3 bước khóa khung + mở Tập 2 sau khi Tập 1 mẫu của Mưa ĐẠT.
