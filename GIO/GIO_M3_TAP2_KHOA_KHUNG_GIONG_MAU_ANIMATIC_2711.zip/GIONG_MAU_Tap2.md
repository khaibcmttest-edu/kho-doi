# Giọng mẫu — Mùa 3 Tập 2 “Tất Bật Chuẩn Bị Đám Cưới Liên Hoàn”

Mỗi nhân vật 1 câu mẫu = câu thoại ĐẦU TIÊN của nhân vật đó trong Tập 2 (trích nguyên văn từ kịch bản Kill, đã nghiệm thu ĐẠT). Tổng hợp VieNeu V3Turbo, chỉnh atempo bằng ffmpeg (không đổi cao độ) trong biên 0,7–1,1 để đạt ~13–17 ký tự/giây (chuẩn ~15). Tốc độ đo trên thời lượng đã cắt khoảng lặng đầu/cuối (ngưỡng 0,004, lề 0,03 giây).

Rùa Biển con và Ông Mặt Trời KHÔNG có thoại ở Tập 2 nên không làm mẫu (chỉ xuất hiện trong hình).

| # | Nhân vật | Giọng VieNeu | atempo bảng | atempo cuối | Câu mẫu (Cảnh) | Ký tự | Thời lượng | Tốc độ (ký tự/giây) |
|---|----------|--------------|-------------|-------------|----------------|-------|------------|----------------------|
| 1 | Giọt Nước Tí | Thái Sơn | 0.9 | 0.7896 | “Có mặt ngay Chị Lá ơi! Hôm nay tụi mình sẽ biến Khu Vườn Kỳ Diệu thành lễ đường lộng lẫy nhất hành tinh!” (Cảnh 1) | 104 | 6.92 giây | 15.03 |
| 2 | Chị Lá | Thùy Dung | 0.739 | 0.7 | “Dậy thôi cả đội ơi! Chỉ còn một ngày nữa là tới lễ cưới liên hoàn của mười cặp đôi rồi, từng tổ vào vị trí chuẩn bị ngay nào!” (Cảnh 1) | 125 | 8.23 giây | 15.19 |
| 3 | Giun Đất | Thái Sơn | 0.95 | 0.9362 | “Đất tơi xốp đủ ẩm thế này thì sáng mai hoa sẽ nở bung rực rỡ đúng giờ lành luôn!” (Cảnh 2) | 80 | 5.32 giây | 15.03 |
| 4 | Bọ Cánh Cứng Cát | Thùy Dung | 0.739 | 0.7197 | “Còn mình và Giun Đất đã trồng xong hai hàng hoa dọc lối đi và đặt đèn sương lấp lánh rồi đây!” (Cảnh 2) | 93 | 6.19 giây | 15.03 |
| 5 | Robot Thám Hiểm | Quốc Tuấn | 0.85 | 0.7812 | “Bíp bíp! Trục lễ đường căn chỉnh chuẩn xác nhờ sự hỗ trợ giữ trụ vững vàng của Cây Đước Ngập Mặn!” (Cảnh 2) | 97 | 6.45 giây | 15.03 |
| 6 | Cây Đước Ngập Mặn | Thục Đoan | 0.85 | 0.9516 | “Có bộ rễ của mình bám đất thì gió bão cũng không lung lay nổi cổng hoa đâu Robot ơi!” (Cảnh 2) | 84 | 5.59 giây | 15.02 |
| 7 | Hoa Tulip | Ngọc Linh | 0.85 | 0.861 | “Khỉ con ơi, bạn treo ngược đầu nên chữ Song Hỷ cũng lộn nhào theo bạn luôn rồi kìa, haha!” (Cảnh 3) | 89 | 5.92 giây | 15.03 |
| 8 | Ếch Cây Mắt Đỏ | Minh Đức | 0.85 | 0.8643 | “Để mình nhảy lên đỡ cho Khỉ con xoay lại ngay, chứ để vậy khách mời phải trồng cây chuối mới đọc được mất!” (Cảnh 3) | 106 | 7.06 giây | 15.02 |
| 9 | Khỉ con | Adam bựa | 0.9 | 0.8307 | “Hahaha, mình quen nhìn thế giới lộn ngược rồi nên thấy chữ nào cũng thuận mắt hết trơn!” (Cảnh 3) | 87 | 5.81 giây | 14.98 |
| 10 | Sâu Xanh | Đức Trí | 0.85 | 1.0254 | “Còn mình và Hoa Tulip kết xong hai trăm vòng hoa tươi mà mình không cắn trộm cánh nào luôn nha!” (Cảnh 3) | 95 | 6.36 giây | 14.94 |
| 11 | Ngựa con | Xuân Vĩnh | 0.9 | 0.7 | “Mình vừa phát xong thiệp mời khắp khu vườn trong chớp mắt, giờ tới màn tập nhịp hành lễ cùng Lạc Đà con nhé!” (Cảnh 4) | 108 | 7.08 giây | 15.25 |
| 12 | Lạc Đà con | Thiền Tâm Đức | 0.8 | 0.9176 | “Leng keng! Tiếng chuông đồng của mình vang chuẩn nhịp như chuông lễ hội luôn rồi nè!” (Cảnh 4) | 84 | 5.60 giây | 15.01 |
| 13 | Sơn Dương con | Thiện Minh | 0.85 | 0.7829 | “Khán đài trên cao đã được mình và Lạc Đà Llama kê phẳng phiu, nhìn bao quát trọn vẹn lễ đường!” (Cảnh 4) | 94 | 6.26 giây | 15.01 |
| 14 | Lạc Đà Llama | Thái Sơn | 0.85 | 0.8356 | “Không một góc khuất nào luôn, ngày mai cả nhà tha hồ ngắm mười cặp đôi tỏa sáng!” (Cảnh 4) | 80 | 5.32 giây | 15.03 |
| 15 | Cá Nhỏ | Ngọc Huyền | 0.85 | 0.726 | “Mình và Cá Hồi Hoa Anh Đào đã thổi xong dải bong bóng nước cầu vồng bay dọc lễ đường rồi nè!” (Cảnh 5) | 92 | 6.12 giây | 15.04 |
| 16 | Cá Hồi Hoa Anh Đào | Thùy Dung | 0.85 | 0.7 | “Nhờ Rùa Biển con điều tiết dòng nước êm dịu nên bong bóng nào cũng tròn xoe lung linh!” (Cảnh 5) | 86 | 5.49 giây | 15.67 |
| 17 | Cáo Tuyết Bắc Cực | Kim Thanh | 0.85 | 1.0451 | “Còn mình và Chim Cánh Cụt con vừa tạo xong các trụ băng pha lê phản chiếu ánh sáng siêu đẹp!” (Cảnh 5) | 92 | 6.14 giây | 14.99 |
| 18 | Chim Cánh Cụt con | Mai Anh | 0.85 | 0.8229 | “Nhìn bóng bẩy đến mức mình suýt trượt bụng lên thử độ trơn luôn đấy, hihi!” (Cảnh 5) | 74 | 4.93 giây | 15.00 |
| 19 | Thỏ Ngọc | Đoan Trang | 0.85 | 0.8116 | “Ánh trăng bạc của mình hòa cùng Tia Nắng Vàng và Chị Mây tạo vầng hào quang cầu vồng đẹp như mơ luôn!” (Cảnh 6) | 101 | 6.72 giây | 15.03 |
| 20 | Tia Nắng Vàng | Quỳnh Anh | 0.85 | 0.8411 | “Ngày mai khi mười cặp đôi bước vào lễ đường, tụi mình sẽ bật hiệu ứng ánh sáng này rực rỡ nhất bầu trời!” (Cảnh 6) | 104 | 6.92 giây | 15.02 |
| 21 | Chị Mây | Mỹ Duyên | 0.85 | 1.0641 | “Chị đã canh chuẩn lượng hơi nước rồi, đảm bảo cầu vồng hiện rõ mà không làm ướt nơ chú rể nào hết!” (Cảnh 6) | 98 | 6.55 giây | 14.97 |
| 22 | Bác Rễ | Adam | 0.794 | 0.7 | “Tuyệt tác! Khi hai mươi lăm thành viên cùng chung tay, Khu Vườn Kỳ Diệu đã hóa thành thánh đường thiên nhiên lộng lẫy nhất!” (Cảnh 7) | 123 | 7.61 giây | 16.16 |
| 23 | Cây Ô Liu Cổ Thụ | Phạm Tuyên | 0.8 | 0.7727 | “Mỗi người một thế mạnh, phối hợp nhịp nhàng không chê vào đâu được, ngày mai chắc chắn sẽ là ngày vui lịch sử!” (Cảnh 7) | 110 | 7.32 giây | 15.04 |
| 24 | Thầy Hồ Tấn Khải | Thái Sơn | 0.95 | 0.7929 | “Thầy Hồ Tấn Khải chúc các em học tốt!” (Cảnh 10) | 37 | 2.44 giây | 15.16 |

## Kết quả

- Đủ **24/24** file WAV (`work/giong_mau/<TEN>_mau.wav`), định dạng pcm_s16le 48 kHz mono — đã kiểm chứng bằng ffprobe từng file.
- **Tốc độ: 24/24 trong ngưỡng 13–17 ký tự/giây** (thấp nhất 14,94 — Sâu Xanh; cao nhất 16,16 — Bác Rễ). Không có giọng nào ngoài ngưỡng, không phải giữ giá trị bảng.
- 4 giọng chạm sàn atempo 0,7 (giá trị cần thấp hơn 0,7 nhưng đã kẹp ở 0,7 và vẫn đạt chuẩn): Chị Lá (cần 0,693 → 15,19), Ngựa con (cần 0,689 → 15,25), Cá Hồi Hoa Anh Đào (cần 0,673 → 15,67), Bác Rễ (cần 0,650 → 16,16).
- Lưu ý: Sâu Xanh (Đức Trí) ở Tập 2 đạt 14,94 ký tự/giây với atempo 1,0254 — khác tiền lệ Vòng 3 Tập 4 (10,62 ký tự/giây, ngoài ngưỡng) vì câu mẫu khác, tốc độ thô của câu này đã nhanh hơn; không cần giữ giá trị bảng.
- File thô (chưa chỉnh atempo) lưu tại `work/giong_mau/raw/` để đối chiếu.

## Trạng thái

- Bước (b) giọng mẫu: XONG — chờ Đạo diễn nghe duyệt (mỗi nhân vật 1 câu mẫu).
- Bước (c) animatic: XONG — file `work/TAP2_ANIMATIC.md`.
- Chưa dựng thật (không làm clip video, không ráp phim), chưa nộp gì lên kho đội.
