# STORYBOARD — TẬP 8: Ý (TUSCANY) "NHỮNG CÂY Ô LIU NGÀN TUỔI VÙNG ĐỊA TRUNG HẢI"
Mùa Ký Sự Vòng 2 · Video hoàn chỉnh 100% · 1920×1080, 30fps · Tổng 226,99 giây (3 phút 47 giây)
Giọng đọc: tất cả nhân vật (Tí, Ngựa con, Cây Ô Liu, Thầy) đều giọng nam **Thái Sơn** (VieNeu) theo đúng mục 4 kịch bản chốt — thầy đã phán kịch bản thắng bảng giọng.
Nhạc nền: music_bed.wav dùng chung, mức 0,42 + **ducking sidechain** (nhạc tự nhỏ xuống khi có thoại).
Chữ ký "✍ Thầy Hồ Tấn Khải": góc phải trên suốt phần phim (0–216,99s); thẻ kết giữ nguyên (chữ ký căn giữa).

---

## Cảnh 1 — Ngựa con đồng hành cùng Tí tới nước Ý (0,00–24,34s · 24,34s)
- **Hình:** Tí (giọt nước xanh trong suốt) và Ngựa con (ngựa vằn sọc đen trắng) cùng nhìn tấm bản đồ nước Ý và biển Địa Trung Hải đang phát sáng. Bối cảnh rừng/cắm trại.
- **Hành động:** Ngựa con hí vang hào hứng khi khán giả bình chọn nước Ý cho Tập 8.
- 🎤 **Giọt Nước Tí:** "Ngựa con ơi, tăng tốc lên nào! Khán giả đã bình chọn đất nước Ý xinh đẹp bên bờ Địa Trung Hải cho Tập 8 rồi! Những ngọn đồi ô liu ngàn năm tuổi đang chờ tụi mình đấy!"
- 🎤 **Ngựa con:** "Hi hí! Những ngọn đồi cỏ thoai thoải ở Tuscany đúng sở trường phi nước đại của mình luôn, vùng Địa Trung Hải có mùa hè nắng ráo khô hạn kéo dài, tụi mình tới xem cây cối ở đó xoay xở ra sao nhé!"

## Cảnh 2 — Những ngọn đồi Tuscany rực nắng mùa hè (24,34–44,34s · 20,00s)
- **Hình:** Những ngọn đồi Tuscany vàng-xanh trập trùng, vườn nho thẳng hàng và đồi ô liu xanh rì dưới trời nắng hè khô ráo.
- **Hành động:** Tí và Ngựa con chạy trên những ngọn đồi Tuscany giữa mùa hè nắng ráo.
- 🎤 **Giọt Nước Tí:** "Ôi đẹp như tranh vẽ luôn Ngựa con ơi! Mà lạ thật, cả mùa hè không có mưa rào mà những đồi cây này vẫn xanh mướt mát thế ạ!"
- 🎤 **Ngựa con:** "Đúng là tài tình thật, hay tụi mình lại gần hỏi thăm bác cây cổ thụ to lớn kia xem bí quyết là gì nhé!"
- *Ghi chú: thoại 15,52s; 4,66s cuối cảnh chỉ có nhạc nền (hình chạy dài hơn thoại).*

## Cảnh 3 — Gặp gỡ Cây Ô Liu Cổ Thụ ngàn năm tuổi (44,34–64,34s · 20,00s)
- **Hình:** Cây Ô Liu Cổ Thụ — thân xù xì màu nâu ấm, lá hẹp xanh bạc, đội mũ quả ô liu xanh, nụ cười hiền hậu — đón Tí và Ngựa con trên sườn đồi Tuscany.
- **Hành động:** Cây Ô Liu Cổ Thụ mỉm cười hiền hậu đón hai vị khách nhỏ phương xa.
- 🎤 **Cây Ô Liu Cổ Thụ:** "Khà khà, chào hai vị khách nhỏ phương xa! Ta là Cây Ô Liu Cổ Thụ, đã sống ở vùng Địa Trung Hải này hàng trăm mùa hè rồi, hôm nay ta sẽ dẫn đường cho hai cháu!"
- 🎤 **Giọt Nước Tí:** "Cháu chào ông Ô Liu ạ! Ông ơi, sao trời mùa hè nắng khô thế này mà lá của ông vẫn bóng loáng xanh tươi vậy ạ?"

## Cảnh 4 — Thi chạy trên đồi Tuscany [CẢNH MỚI] (64,34–84,34s · 20,00s)
- **Hình:** Tí, Ngựa con và Cây Ô Liu Cổ Thụ thi chạy trên đồi nắng; Tí lăn lông lốc xuống dốc như quả bóng nước, vườn nho bao quanh.
- **Hành động:** Ngựa con rủ Tí thi chạy; Tí chạy vài bước thì đồi dốc quá nên lăn xuống như quả bóng nước, tới gốc ô liu trước cả Ngựa con; Cây Ô Liu cười khà khà.
- 🎤 **Ngựa con:** "Thi chạy trên đồi nè Tí! Ai chạy tới gốc ô liu kia trước thì thắng, mình phi nước đại!"
- 🎤 **Giọt Nước Tí:** "Mình chạy! Ơ... đồi dốc quá, mình lăn lông lốc xuống như quả bóng nước, haha, tới nơi rồi!"
- 🎤 **Cây Ô Liu Cổ Thụ:** "Khà khà, Tí lăn nhanh hơn cả ngựa chạy, giỏi quá!!"
- *Ghi chú: thoại 16,54s; 3,56s cuối cảnh chỉ có nhạc nền.*

## Cảnh 5 — Bí mật lớp sáp cutin dày và phiến lá cứng (84,34–108,38s · 24,04s)
- **Hình:** Cận cảnh mặt cắt phiến lá ô liu: lớp sáp cutin dày bóng loáng phản xạ tia nắng, khí khổng nằm sâu ở mặt dưới lá.
- **Hành động:** Hình cắt lớp phiến lá hiện rõ lớp sáp cutin phản xạ nắng và khí khổng ẩn sâu dưới mặt lá.
- 🎤 **Cây Ô Liu Cổ Thụ:** "Cháu nhìn kỹ phiến lá của ta nhé: lá nhỏ, dày và cứng, mặt trên phủ một lớp sáp cutin dày bóng loáng như chiếc áo chống nắng phản xạ bớt tia sáng mạnh! Còn khí khổng thì nằm ẩn sâu ở mặt dưới có lớp lông che chở, giúp hạn chế tối đa thoát hơi nước suốt mùa hè khô hạn đấy!"
- 🎤 **Ngựa con:** "Thảo nào nắng hè gay gắt cũng không làm lá của ông bị héo!"

## Cảnh 6 — Máy bay không người lái Drone quét cánh đồng nho [CẢNH ĂN TIỀN] (108,38–132,44s · 24,06s)
- **Hình:** Drone nông nghiệp đa phổ bay là là trên vườn nho, chiếu tia quét lập bản đồ sức khỏe từng gốc cây lên màn hình máy tính bảng.
- **Hành động:** Drone bay lượn trên vườn nho, chiếu tia quét lập bản đồ sức khỏe từng gốc cây.
- 🎤 **Giọt Nước Tí:** "Ngựa con ơi nhìn kìa! Có chiếc máy bay nhỏ bốn cánh đang bay là là trên vườn nho và chiếu tia sáng quét từng luống cây!"
- 🎤 **Cây Ô Liu Cổ Thụ:** "Đó là thiết bị bay không người lái Drone ứng dụng trong nông nghiệp chính xác đấy! Camera đa phổ trên Drone chụp ảnh phân tích sức khỏe từng gốc nho, phát hiện sớm cây nào thiếu nước hay chớm sâu bệnh để chăm sóc kịp thời!"
- *Ghi chú: màn hình máy tính bảng có ký tự gibberish li ti (lỗi từ ảnh gốc, không sửa được khi ráp).*

## Cảnh 7 — Thu hoạch nho & ô liu chuẩn độ chín (132,44–152,44s · 20,00s)
- **Hình:** Vườn nho nắng vàng thu hoạch: nông dân hái chùm nho tím mọng và giỏ quả ô liu căng tròn đạt chuẩn.
- **Hành động:** Thu hoạch nho tím mọng và ô liu căng tròn đạt chuẩn chất lượng cao.
- 🎤 **Ngựa con:** "Nhờ chăm sóc chính xác từng gốc cây như vậy mà quả nho và quả ô liu nào cũng căng mọng, đều tăm tắp!"
- 🎤 **Cây Ô Liu Cổ Thụ:** "Đúng vậy! Sự kết hợp giữa giống cây thích nghi khí hậu Địa Trung Hải và công nghệ số hiện đại đã tạo nên những nông sản trứ danh khắp thế giới!"
- *Ghi chú: thoại 16,68s; 3,38s cuối cảnh chỉ có nhạc nền.*

## Cảnh 8 — Thử hái ô liu và ép dầu mini [CẢNH MỚI] (152,44–172,44s · 20,00s)
- **Hình:** Tí, Ngựa con và Cây Ô Liu Cổ Thụ hái ô liu và ép dầu mini trên sườn đồi; Tí bị dầu ô liu văng tung tóe làm bóng loáng trơn tuột, cười khúc khích.
- **Hành động:** Cả ba thử hái ô liu và ép dầu mini; Tí xung phong ép thử rồi bị dầu văng tung tóe.
- 🎤 **Cây Ô Liu Cổ Thụ:** "Thử hái ô liu và ép dầu mini nè các cháu! Hái quả chín mọng, ép nhẹ nhàng là dầu vàng óng chảy ra!"
- 🎤 **Giọt Nước Tí:** "Để cháu thử ép nhé! Ôi trời, dầu ô liu văng tung tóe làm cháu bóng loáng trơn tuột, hahaha, cháu thành giọt dầu vàng óng rồi!"
- *Ghi chú: thoại 17,21s; 2,91s cuối cảnh chỉ có nhạc nền.*

## Cảnh 9 — Ghi chép sổ tay Sinh học & Công nghệ nông nghiệp (172,44–192,44s · 20,00s)
- **Hình:** Tí ghi chép vào sổ tay hành trình phát sáng toàn ảnh (holographic): hai sơ đồ khoa học — giải phẫu lớp sáp cutin của lá ô liu và bản đồ Drone quét cây trồng.
- **Hành động:** Tí ghi chép bài học vào sổ tay với hai sơ đồ khoa học phát sáng.
- 🎤 **Giọt Nước Tí:** "Sổ tay hành trình sắp kín trang rồi! Bài học Sinh học hôm nay: thực vật vùng khí hậu Địa Trung Hải có lá nhỏ cứng phủ sáp cutin dày để chống thoát hơi nước mùa hè khô nóng. Bài học Công nghệ nông nghiệp: thiết bị bay không người lái Drone giúp theo dõi sức khỏe cây trồng và bón phân, tưới nước chính xác!"

## Cảnh 10 — Chốt chặng về đích Tập 9 & Lời kết chuẩn (192,44–216,99s · 24,55s)
- **Hình:** Tí, Ngựa con và Cây Ô Liu Cổ Thụ vẫy tay chào bên thẻ hành trình vàng phát sáng "Tập 9 (Vietnam - Mekong Delta)" và biểu tượng sách giáo khoa mở.
- **Hành động:** Cả ba vẫy tay chào; thẻ chặng cuối về Việt Nam bật sáng cùng biểu tượng mở SGK.
- 🎤 **Giọt Nước Tí:** "Đi khắp năm châu bốn bể, nơi đâu có những cánh đồng lúa chín vàng thẳng cánh cò bay, rừng đước xanh rì bên cửa biển và những vườn cây trái trĩu quả quê hương mình? Chặng cuối Vòng 2 gọi tên: Việt Nam — Đồng bằng sông Cửu Long! Đừng quên mở sách giáo khoa Sinh học 11 bài Quang hợp và thoát hơi nước, bấm đăng ký kênh và bật chuông nhé!"
- 🎤 **Thầy Hồ Tấn Khải:** "Thầy Hồ Tấn Khải chúc các em học tốt!"
- *Ghi chú: do camera push-in, thẻ vàng ra ngoài khung ở cuối cảnh (vẫn thấy rõ ở đầu/giữa cảnh).*

## Thẻ kết (216,99–226,99s · 10,00s)
- **Hình:** Khung cảnh cuối (Drone trên vườn nho) làm nền, zoom chậm + pan; chữ ký "✍ Thầy Hồ Tấn Khải" căn giữa + dòng "Đăng ký kênh Thầy Khaibcmt để xem tiếp Tập 9!".
- **Tiếng:** chỉ nhạc nền (fade out 3s cuối), không thoại, không chữ ký góc.

---
*Storyboard viết từ kịch bản chốt Kich_Ban_Tap8_Y_10canh.txt + lines.json (thoại trích đúng từng chữ, 20 câu, 2.891 ký tự).*
