# STORYBOARD — TẬP 7: ISRAEL (SA MẠC NEGEV) "PHÉP MÀU BIẾN SỎI ĐÁ THÀNH VƯỜN CÂY"
Vòng 2 Mùa Ký Sự "Giọt nước Tí phiêu lưu khắp thế giới" · Nhân vật: Giọt Nước Tí, Lạc Đà con (hướng dẫn viên) · Giọng: tất cả Thái Sơn (theo kịch bản chốt) · Thoại: 19 câu, 2.890 ký tự · Tốc độ đọc ~14,5 ký tự/giây (atempo Tí 0,90 / Lạc Đà con 0,90 / Thầy 0,95) · Nhạc nền music_bed.wav mức 0,42 + ducking · Chữ ký "✍ Thầy Hồ Tấn Khải" góc phải trên suốt phần phim · Thẻ kết 10 giây cuối phim.

## Cảnh 1 — Lạc Đà con tiếp tục đồng hành cùng Tí tới Israel (25,0 giây)
- **Hình:** Tí và Lạc Đà con nhìn bản đồ phát sáng chỉ tới Israel và sa mạc Negev.
- **🎤 Giọt Nước Tí:** "Lạc Đà con ơi, xuất phát thôi nào! Tập 7 khán giả đã bình chọn đất nước Israel ở vùng Trung Đông rồi! Mình háo hức xem người dân biến vùng đất sỏi đá thành vườn cây xanh mát lắm!"
- **🎤 Lạc Đà con:** "Vùng bán khô hạn Negev ở Israel chính là nơi con người tạo nên kỳ tích biến cát sỏi thành vựa trái cây xuất khẩu đấy Tí ơi, đi khám phá ngay thôi!"

## Cảnh 2 — Đồi sỏi đá Negev khô cằn (20,0 giây)
- **Hình:** Đồi sỏi đá khô cằn dưới nắng gắt; Tí và Lạc Đà con đi qua những hàng cây chà là và ô liu xanh tốt, trĩu quả.
- **🎤 Giọt Nước Tí:** "Lạc Đà con ơi nhìn kìa! Vùng Negev này toàn sỏi đá khô cằn mà sao những hàng cây chà là và ô liu vẫn mọc xanh tốt và trĩu quả thế ạ?"
- **🎤 Lạc Đà con:** "Vì chúng có cấu tạo rễ và lá thích nghi cực kỳ thông minh với môi trường thiếu nước đấy Tí ạ!"

## Cảnh 3 — Bí mật bộ rễ sâu và chiếc áo lá ánh bạc (24,7 giây)
- **Hình:** Hình cắt lớp lòng đất: rễ cọc cây chà là và ô liu đâm sâu xuống mạch nước ngầm; mặt lá phủ lông bạc lấp lánh phản xạ nắng.
- **🎤 Giọt Nước Tí:** "Ồ, nhìn mặt lá của những cây ô liu và chà là ở đây có lớp lông mịn màu bạc lấp lánh dưới nắng kìa!"
- **🎤 Lạc Đà con:** "Lớp lông bạc ấy giúp phản xạ bớt ánh nắng gay gắt để lá không bị quá nóng, giảm thoát hơi nước! Còn bên dưới lòng đất, bộ rễ cọc của chúng đâm sâu hàng chục mét để hút nước và ion khoáng từ tầng ngậm nước sâu đấy!"

## Cảnh 4 — Thi tìm nước trong sỏi đá [CẢNH MỚI] (20,0 giây)
- **Hình:** Tí và Lạc Đà con thi đào tìm nước giữa đồi sỏi đá; Tí đào mãi chỉ thấy sỏi, nhặt được viên sỏi hình trái tim.
- **🎤 Lạc Đà con:** "Thi tìm nước trong sỏi đá nè Tí ơi! Ai đào được nước dưới lòng đất trước thì thắng nhé!"
- **🎤 Giọt Nước Tí:** "Mình đào đây!! Đào mãi chỉ thấy toàn sỏi đá, nhưng mình nhặt được viên sỏi hình trái tim đẹp ơi là đẹp này! Còn nước thì ở đâu hả bạn?"

## Cảnh 5 — Nhà máy tái chế 90% nước thải thành nước tưới (25,6 giây)
- **Hình:** Nhà máy tái chế nước hiện đại ở Israel: nước thải sinh hoạt được lọc sạch thành nước tưới trong vắt chảy ra sa mạc qua đường ống.
- **🎤 Giọt Nước Tí:** "Tuyệt quá! Người dân Israel lấy đâu ra nhiều nước ngọt để tưới cho cả vùng sa mạc rộng lớn thế ạ?"
- **🎤 Lạc Đà con:** "Israel là quốc gia dẫn đầu thế giới về tái sử dụng nước! Hơn chín mươi phần trăm nước thải sinh hoạt được thu gom, lọc sạch qua nhiều tầng sinh học và màng lọc hiện đại để dẫn ra sa mạc tưới cây, không bỏ phí một giọt nào!"

## Cảnh 6 — Cảm biến độ ẩm đất IoT điều khiển tưới thông minh (24,9 giây)
- **Hình:** Cảm biến độ ẩm đất cắm dưới gốc cây phát tín hiệu không dây lên màn hình máy tính bảng, mở van tưới nhỏ giọt chính xác từng giọt.
- **🎤 Giọt Nước Tí:** "A, dưới gốc cây có chiếc que nhỏ phát sáng tín hiệu kìa, nó làm nhiệm vụ gì thế Lạc Đà con?"
- **🎤 Lạc Đà con:** "Đó là cảm biến độ ẩm đất kết nối Internet vạn vật! Khi rễ cây vừa chớm thiếu nước, cảm biến gửi tín hiệu về máy chủ để tự động mở van tưới nhỏ giọt chính xác từng mililít nước và phân bón, cây đủ nước là tự ngắt ngay!"

## Cảnh 7 — Vườn hoa trái ngọt ngào giữa sa mạc Negev [CẢNH ĂN TIỀN] (22,0 giây)
- **Hình:** Vườn cam vàng và lựu đỏ mọng sai trĩu quả giữa sa mạc sỏi đá, tưới bằng đường ống nhỏ giọt.
- **🎤 Giọt Nước Tí:** "Nhìn những chùm cam vàng và quả lựu đỏ mọng giữa sa mạc sỏi đá mà mình xúc động quá! Khi con người hiểu quy luật Sinh học của cây trồng và áp dụng Công nghệ nông nghiệp thông minh thì vùng đất cằn cỗi cũng hóa thành vườn cây trù phú!"
- **🎤 Lạc Đà con:** "Đúng vậy Tí ơi, tiết kiệm từng giọt nước chính là chìa khóa của tương lai!"

## Cảnh 8 — Thử tưới nhỏ giọt cho cây cam con [CẢNH MỚI] (20,0 giây)
- **Hình:** Tí và Lạc Đà con thử tưới nhỏ giọt cho cây cam con; Tí chạy trong ống tưới như tàu lượn siêu tốc rồi bật ra đúng gốc cây.
- **🎤 Lạc Đà con:** "Thử tưới nhỏ giọt cho cây cam con nè Tí! Gắn cảm biến, mở van, nước nhỏ đúng gốc cây nhé!"
- **🎤 Giọt Nước Tí:** "Để mình chạy trong ống tưới xem sao! Ôi trời, mình lao đi như tàu lượn siêu tốc, tới gốc cây rồi đây, hahaha, cây mau lớn nhanh nhé!"

## Cảnh 9 — Ghi chép sổ tay Sinh học & Công nghệ nông nghiệp (22,9 giây)
- **Hình:** Tí ghi chép vào sổ tay hành trình phát sáng: sơ đồ rễ cọc hút nước ngầm và vòng lặp tưới nhỏ giọt IoT.
- **🎤 Giọt Nước Tí:** "Mình ghi ngay vào sổ tay thôi! Bài học Sinh học hôm nay: thực vật vùng khô hạn có rễ cọc ăn sâu hút nước ngầm và lá phủ lông bạc phản xạ nhiệt. Bài học Công nghệ nông nghiệp: tái sử dụng nước thải kết hợp cảm biến IoT và tưới nhỏ giọt chính xác giúp làm nông nghiệp bền vững trên vùng đất cằn!"

## Cảnh 10 — Bình chọn Tập 8 & Lời kết chuẩn (27,2 giây)
- **Hình:** Tí và Lạc Đà con vẫy tay chào bên hai thẻ bình chọn Tập 8 (Ý, Việt Nam) và biểu tượng mở sách giáo khoa.
- **🎤 Giọt Nước Tí:** "Sau sa mạc Negev đầy nắng gió, điểm đến tiếp theo có những đồi ô liu bạc ngàn năm tuổi, những vườn nho trĩu quả và những chiếc máy bay không người lái bay lượn trên cánh đồng! Bình chọn Tập 8: Ý hay Việt Nam! Đừng quên mở sách giáo khoa Sinh học 11 bài Trao đổi nước và khoáng ở thực vật, bấm đăng ký kênh và bật chuông nhé!"
- **🎤 Thầy Hồ Tấn Khải:** "Thầy Hồ Tấn Khải chúc các em học tốt!"

## Thẻ kết (10 giây)
- **Hình:** Khung cảnh cuối làm nền, chữ ký "✍ Thầy Hồ Tấn Khải" căn giữa + "Đăng ký kênh Thầy Khaibcmt để xem tiếp Tập 8!". Không gắn chữ ký phủ góc.
