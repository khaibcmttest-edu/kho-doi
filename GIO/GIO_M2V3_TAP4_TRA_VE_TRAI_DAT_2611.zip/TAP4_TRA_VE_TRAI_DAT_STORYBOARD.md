# STORYBOARD — TẬP 4: TRỞ VỀ TRÁI ĐẤT (TẬP CUỐI TOÀN SERIES) — BẢN V3-FIX (sửa C10 + Lạc Đà con C2/C8 theo lệnh thầy 26/11)
Mùa Ký Sự Vòng 3 · Video hoàn chỉnh 100% · 1920×1080, 30fps · Tổng 229,85 giây (3 phút 50 giây)
Giọng đọc (BẢN V3 — bảng giọng thầy chốt 26/11, thắng kịch bản): Tí = Thái Sơn 0,90 · Chị Lá = Thùy Dung 0,739 · Lạc Đà con = Thiền Tâm Đức 0,80 · Bác Rễ = Adam 0,794 · Sâu Xanh = Đức Trí 0,85 · Ông Mặt Trời = Minh Triết 0,814 · Rùa Biển con = Thanh Bình 0,80 · Chim Cánh Cụt con = Mai Anh 0,85 · Khỉ con = Adam bựa 0,90 · Giun Đất = Thái Sơn 0,95 · Cá Nhỏ = Ngọc Huyền 0,85 · Thầy = Thái Sơn 0,95 · Robot = Quốc Tuấn 0,85 (không xuất hiện ở tập này).
Nhạc nền: music_bed.wav dùng chung, mức 0,42 + **ducking sidechain** (nhạc tự nhỏ xuống khi có thoại).
Chữ ký "✍ Thầy Hồ Tấn Khải": góc phải trên suốt phần phim (0–219,85s); thẻ kết giữ nguyên (chữ ký căn giữa).
Thông điệp: Trái Đất là ngôi nhà chung kỳ diệu — chung tay bảo vệ sinh quyển và nông nghiệp bền vững.

---

## Cảnh 1 — Hạ cánh xuyên tầng khí quyển trở về Trái Đất (0,00–19,50s · 19,50s)
- **Hình:** Giọt Nước Tí trong Bong Bóng Phép Thuật vàng lướt nhẹ qua tầng mây trắng, đáp xuống bầu trời xanh trong lành của Trái Đất.
- **Hành động:** Tí trong bong bóng lướt qua mây của Chị Mây, hạ cánh về hành tinh xanh.
- 🎤 **Giọt Nước Tí:** "Trái Đất yêu dấu ơi, Giọt Nước Tí đã trở về rồi đây! Sau khi đi qua Cung Trăng lạnh giá, Sao Hỏa khô cằn và ngôi nhà rực lửa của Ông Mặt Trời, mình mới thấm thía rằng không nơi đâu trong vũ trụ đẹp và ấm áp bằng hành tinh xanh của chúng ta!"

## Cảnh 2 — Ngày hội ngộ lớn tại Khu Vườn Kỳ Diệu (19,50–40,55s · 21,05s)
- **Hình:** Cả đội vườn nhà cùng 7 chuyên gia thích nghi tụ họp đông đủ trong khu vườn nắng vàng đón Tí trở về. Lạc Đà con ĐÃ CÓ MẶT (ảnh v3 sửa 26/11: lạc đà một bướu + chuông đồng, đủ 14 nhân vật); Ngựa con ngựa vằn, Chị Lá da hồng đào.
- *Ghi chú: clip mới vẽ lại — Sơn Dương con vắng trong clip (không thoại ở Cảnh 2); Cá Nhỏ CAM trong clip (công cụ video vẽ lại mặc định Nemo cam, như mọi clip trước).*
- **Hành động:** Bong Bóng Phép Thuật tan thành ánh nắng vàng; cả đội ùa ra ôm chầm lấy Tí.
- 🎤 **Chị Lá:** "Chào mừng Giọt Nước Tí đã hoàn thành chuyến phiêu lưu từ vườn nhà ra khắp thế giới và vươn tới tận vũ trụ!"
- 🎤 **Lạc Đà con:** "Cả bảy chuyên gia tụi mình cũng đã tụ họp đông đủ tại khu vườn kỳ diệu để chúc mừng Tí đây!"
- 🎤 **Bác Rễ:** "Cháu đã mang về cả một kho tàng tri thức quý giá cho tất cả chúng ta!"

## Cảnh 3 — Nhìn lại hành trình 3 vòng khám phá kỳ diệu (40,55–60,83s · 20,28s)
- **Hình:** Ba quả cầu ký ức 3D phát sáng lơ lửng trên vườn: Vòng 1 khu vườn nhà, Vòng 2 chín quốc gia, Vòng 3 Cung Trăng–Sao Hỏa–Ông Mặt Trời; cả đội cùng ngắm.
- **Hành động:** Ba quả cầu ký ức bật sáng tái hiện trọn vẹn hành trình 3 vòng.
- 🎤 **Giọt Nước Tí:** "Nhìn lại ba chặng đường đã qua: từ những bí mật hút nước, quang hợp ngay trong khu vườn nhà, đến khả năng thích nghi kỳ diệu của sinh vật từ sa mạc Sahara tới băng giá Bắc Cực, rồi vươn ra Cung Trăng, Sao Hỏa và Ông Mặt Trời — tất cả đều gắn kết bởi những quy luật Sinh học tuyệt vời!"
- *Ghi chú: Cá Nhỏ trong clip vẫn CAM (công cụ video vẽ lại mặc định Nemo cam; cá nhỏ ~100px). Ảnh tĩnh Canh3_v2.png đã hồng nhưng clip vẽ lại vẫn cam. Cừu trắng VẪN CÒN thay cho Lạc Đà con ở cảnh này (2 lần sửa ảnh đều thất bại — công cụ sửa ảnh làm mất Khỉ con / Sơn Dương con; giữ nguyên clip C3 v2 cũ theo giới hạn thử).*

## Cảnh 4 — Đố vui nhận diện hành tinh cùng cả đội vườn nhà [CẢNH MỚI] (60,83–80,87s · 20,04s)
- **Hình:** Tí cầm mô hình 3D phát sáng của Mặt Trăng, Sao Hỏa và Trái Đất; Sâu Xanh và Sơn Dương con háo hức giơ tay chơi đố vui trong vườn nắng.
- **Hành động:** Tí mở trò chơi đố vui nhanh; Sâu Xanh đoán nhầm rồi gãi đầu cười tít, Sơn Dương con bổ sung chuẩn xác, cả vườn vỗ tay.
- 🎤 **Giọt Nước Tí:** "Đố vui cả đội nè! Nơi nào có trọng lực nhẹ giúp nhảy bổng lên cao nhưng lại không có không khí để thở tự nhiên?"
- 🎤 **Sâu Xanh:** "Dạ là Sao Hỏa ạ! Ơ... nhầm rồi, là Cung Trăng mới đúng, trên đó không có lá xanh cho mình gặm đâu, hahaha!"
- *Ghi chú: Sâu Xanh giọng Đức Trí đọc chậm 10,62 ký tự/giây (đã chỉnh tối đa +0,1 cho phép; muốn về 15 phải atempo ~1,34, vượt biên 0,7–1,1).*

## Cảnh 5 — Vì sao Trái Đất là hành tinh duy nhất có sự sống? [CẢNH ĂN TIỀN] (80,87–101,69s · 20,82s)
- **Hình:** Mô hình Trái Đất 3D trong vùng Goldilocks: đại dương nước lỏng, bầu khí quyển, rừng xanh; Ông Mặt Trời mặt đỏ-cam rạng rỡ và Rùa Biển con giải thích cho cả đội.
- **Hành động:** Mô hình Trái Đất hiện lên với khoảng cách vàng tới Mặt Trời, đại dương nước lỏng, bầu khí quyển bảo vệ và sinh quyển trù phú.
- 🎤 **Ông Mặt Trời:** "Trái Đất nằm ở khoảng cách vàng hoàn hảo so với ông, nên có nước tồn tại ở thể lỏng, có bầu khí quyển giàu ôxi và tầng ôzôn che chắn tia bức xạ!"
- 🎤 **Rùa Biển con:** "Nhờ vậy mà từ đại dương sâu thẳm đến rừng xanh, đồng cỏ và núi cao, muôn loài sinh vật cùng chung sống tạo nên một Sinh quyển kỳ diệu!"
- *Ghi chú: chân Rùa chạm/cắt nhẹ ở đáy khung (như ảnh gốc).*

## Cảnh 6 — Chung tay bảo vệ Sinh quyển & Nông nghiệp bền vững (101,69–121,65s · 19,96s)
- **Hình:** Tầm nhìn Trái Đất xanh sạch: rừng xanh, sông sạch, nông trại sinh thái; Tí, Chị Lá, Chim Cánh Cụt con (khăn len) và Khỉ con (đuôi cong) cùng chăm sóc mầm xanh.
- **Hành động:** Cả đội cùng nhau chăm sóc mầm xanh trong vườn, hình ảnh Trái Đất xanh sạch đẹp hiện lên rạng rỡ.
- 🎤 **Chim Cánh Cụt con:** "Nếu Trái Đất nóng lên hay ô nhiễm thì băng hai cực sẽ tan chảy và muôn loài sẽ mất đi ngôi nhà chung!"
- 🎤 **Khỉ con:** "Vì vậy mỗi chúng ta hãy tiết kiệm từng giọt nước, trồng thêm nhiều cây xanh, bảo vệ rừng và áp dụng công nghệ nông nghiệp sạch để giữ mãi màu xanh cho hành tinh này!"

## Cảnh 7 — Cuốn sách Tri thức Sống mở ra cho thế hệ trẻ (121,65–141,15s · 19,50s)
- **Hình:** Tí đặt cuốn sổ tay hành trình đã hoàn thành lên bệ bên cạnh cuốn sách giáo khoa Sinh học mở ra, tỏa ánh sáng vàng khắp khu vườn.
- **Hành động:** Tí đặt sổ tay hành trình bên cạnh SGK Sinh học phát sáng rực rỡ.
- 🎤 **Giọt Nước Tí:** "Cuốn sổ tay hành trình của mình đã viết kín những bài học Sinh học và Công nghệ nông nghiệp quý giá rồi! Mình tin rằng khi các bạn học sinh yêu thiên nhiên và nắm vững khoa học, chính các bạn sẽ là những người bảo vệ và làm đẹp cho Trái Đất mai sau!"

## Cảnh 8 — Cả đội cùng trồng cây xanh giữ màu xanh Trái Đất [CẢNH MỚI] (141,15–160,65s · 19,50s)
- **Hình:** Cả đội trong vườn nắng cùng trồng cây non: Giun Đất xới đất, Bác Rễ nâng rễ, Sâu Xanh đặt phân hữu cơ, Tí tưới nước mát; Lạc Đà con ĐÃ CÓ MẶT (ảnh v3 sửa 26/11 — cừu trắng đã được thay bằng lạc đà một bướu + chuông đồng, đủ 14 nhân vật).
- **Hành động:** Cả đội thực hành trồng một cây non giữa khu vườn trong tiếng vỗ tay của mọi người.
- 🎤 **Bác Rễ:** "Nào cả đội ơi, mình cùng trồng thêm một mầm xanh mới để góp phần bảo vệ sinh quyển Trái Đất ngôi nhà chung nhé!"
- 🎤 **Giọt Nước Tí:** "Cháu tưới nước mát cho cây ngay đây ạ! Chúc mầm xanh mau vươn cao tỏa bóng mát cho khu vườn kỳ diệu của tụi mình!"
- *Ghi chú: clip mới vẽ lại — Chị Lá vắng trong clip (không thoại ở Cảnh 8); Cá Nhỏ CAM trong clip (công cụ video vẽ lại mặc định Nemo cam).*

## Cảnh 9 — Lời cảm ơn khán giả của toàn đội nhân vật (160,65–194,84s · 34,19s)
- **Hình:** Tất cả 14 nhân vật xếp hàng ngay ngắn trong khu vườn đầy nắng, cúi chào và mỉm cười cảm ơn khán giả. Cá Nhỏ trong bong bóng lớn.
- **Hành động:** Cả đội cúi chào, mỉm cười cảm ơn khán giả đã đồng hành suốt 3 vòng.
- 🎤 **Giọt Nước Tí:** "Hành trình của Giọt Nước Tí qua khu vườn nhà, vòng quanh thế giới và bay vào vũ trụ xin được khép lại tại đây! Thay mặt cả đội vườn nhà và bảy chuyên gia thích nghi, Tí xin gửi lời cảm ơn chân thành nhất tới quý thầy cô, quý phụ huynh và tất cả các bạn khán giả đã luôn yêu thương, bình chọn và đồng hành suốt cả ba vòng qua!"
- 🎤 **Giun Đất:** "Cảm ơn các bạn nhỏ đã luôn theo dõi hành trình của tụi mình!"
- 🎤 **Cá Nhỏ:** "Hẹn gặp lại tất cả các bạn trong những hành trình khám phá khoa học mới thật bổ ích và kỳ thú nhé!"
- *Ghi chú: dùng clip thử lần 2 (đủ 14 nhân vật, camera tĩnh) — Cá Nhỏ vẫn CAM (công cụ video vẽ lại mặc định Nemo cam); nguồn 1632×544 xử lý bằng nền mờ (blurred fill), không viền đen, không biến dạng; đã bỏ hoàn toàn audio gốc của clip. Ông Mặt Trời trong cảnh này là mặt trời vàng cười (không thấy rõ mặt đỏ-cam nhỏ + râu vàng theo mô tả khoá).*

## Cảnh 10 — Lời kết Series, mở SGK & Chữ ký Thầy Hồ Tấn Khải (194,84–219,85s · 25,01s)
- **Hình:** Tí vẫy tay chào tạm biệt lưu luyến trước biểu ngữ "Cảm Ơn Khán Giả - Hẹn Gặp Lại", cuốn SGK Sinh học 12 mở ra và chữ ký vàng của Thầy.
- **Hành động:** Tí vẫy tay chào tạm biệt; biểu tượng mở SGK, nút đăng ký kênh và chữ ký Thầy hiện lên trang trọng.
- 🎤 **Giọt Nước Tí:** "Chúc các bạn luôn chăm ngoan, học giỏi và giữ mãi ngọn lửa tò mò khám phá thế giới tự nhiên! Đừng quên mở sách giáo khoa Sinh học 12 bài Sinh quyển và bảo vệ đa dạng sinh học, bấm đăng ký kênh và bật chuông để đón chờ những dự án giáo dục tiếp theo của thầy nhé!"
- 🎤 **Thầy Hồ Tấn Khải:** "Thầy Hồ Tấn Khải cảm ơn các em đã đồng hành suốt series và chúc các em học tốt!"
- *Ghi chú: clip gốc có viền đen pillarbox 2 bên (100px mỗi bên) — đã crop bỏ viền khi dựng lại đoạn C10 ngày 26/11; biển chữ mờ "Cảm Ơn Khán Giả - Hẹn Gặp Lại" ở đầu clip giữ nguyên.*

## Thẻ kết (219,85–229,85s · 10,00s)
- **Hình:** Nền khung Cảnh 5 (Trái Đất + Ông Mặt Trời) làm mờ; chữ ký Thầy căn giữa + "Cảm ơn các em đã theo dõi!" + "Đăng ký kênh Thầy Khaibcmt".
- **Hành động:** Zoom chậm 1,0 → 1,35; không có chữ ký góc phải trên ở thẻ kết.
- 🎤 Không thoại — chỉ nhạc nền.
