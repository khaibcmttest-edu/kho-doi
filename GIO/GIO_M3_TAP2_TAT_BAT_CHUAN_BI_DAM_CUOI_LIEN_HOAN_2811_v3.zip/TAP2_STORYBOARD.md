# STORYBOARD — Mùa 3 Tập 2: “Tất Bật Chuẩn Bị Đám Cưới Liên Hoàn”

**Series:** Giọt Nước Tí — Mùa 3 “Cưới Nhau” (kịch bản Kill, đã nghiệm thu ĐẠT).
**Chuẩn tham chiếu:** Tập 1 mẫu của Mưa (268,40s, loudnorm I −15,77; xem `work/NGHIEN_CUU_TAP1_MAU.md`).
**Khóa khung đã duyệt ĐẠT (Đạo diễn ca 17:59 ngày 27/11):** (a) hình chuẩn trưởng thành 25/25 của Mưa,
(b) giọng mẫu 24 giọng, (c) animatic `work/TAP2_ANIMATIC.md`.
**Lồng tiếng đầy đủ:** `work/tts_full/` — 28/28 lượt thoại, 2.971 ký tự, tốc độ 14,94–16,16 ký tự/giây
(24 lượt tái dùng file giọng mẫu đã duyệt; 4 lượt mới: Bác Rễ C8, Chị Lá C8, Tí C9, Tí C10).
**Nhạc nền:** `music_bed.wav` (md5 `787908b773d9caf4cfc632c93d1c5e57` đã kiểm chứng), lặp liền volume 0,42 +
ducking sidechaincompress (threshold 0,02, ratio 8).
**Chữ ký:** `work/signature_overlay.png` 370×53px (19,27% khung, vàng nhạt 255,243,176) —
overlay `W-w-26:24` phủ suốt phần phim + thẻ kết.

## Thời lượng (đo thực từ thoại — segment = max(20s, thoại + 1,6s))

| Cảnh | Ký tự | Thoại (s) | Segment (s) | Mốc bắt đầu (s) | Thoại bắt đầu (s) |
|---|---|---|---|---|---|
| C1 | 229 | 16,35 | 20,00 | 0,00 | 0,80 |
| C2 | 354 | 25,56 | 27,16 | 20,00 | 20,80 |
| C3 | 377 | 27,14 | 28,74 | 47,16 | 47,96 |
| C4 | 366 | 26,26 | 27,86 | 75,90 | 76,70 |
| C5 | 344 | 24,68 | 26,28 | 103,76 | 104,56 |
| C6 | 303 | 21,79 | 23,39 | 130,04 | 130,84 |
| C7 | 233 | 16,13 | 20,00 | 153,43 | 154,23 |
| C8 | 271 | 18,94 | 20,54 | 173,43 | 174,23 |
| C9 | 233 | 16,33 | 20,00 | 193,97 | 194,77 |
| C10 | 261 | 18,51 | 20,11 | 213,97 | 214,77 |
| Thẻ kết | — | — | 10,00 | 234,08 | — |

**Tổng segment 10 cảnh: 234,08s; phim (segment + thẻ kết 10s): 244,08s (≈ 4'04").**
Dài hơn ước tính animatic (216,3s) +17,78s — đúng bài học tập mẫu (+14,73s; thoại đo thực +
khoảng nghỉ 0,8s đầu đoạn + 0,4s giữa các lượt + 1,6s đuôi đoạn).

**Hệ số làm chậm clip (segment ÷ 10s):** C1 2,000 · C2 2,716 · C3 2,874 · C4 2,786 · C5 2,628 ·
C6 2,339 · C7 1,000 + 1,000 (2 góc × 10s) · C8 2,054 · C9 2,000 · C10 2,011.
Filter chuẩn Mưa: `setpts={hệ số}*PTS, scale=2112:1188, crop=1920:1080:x='(in_w-out_w)*t/{segment}':y='(in_h-out_h)/2', fps=30`.
Tuyệt đối KHÔNG lặp, KHÔNG tua ngược, KHÔNG crossfade.

---

## Cảnh 1 — Tiếng còi báo thức buổi sáng của Tổng đạo diễn Chị Lá (20,00s)

**Prompt clip (EN, animatic + câu khóa):**
> Early morning in the garden as a vibrant cheerful green leaf character with big expressive eyes, tiny arms and legs, wearing a white pomelo-blossom hairclip holds a glowing checklist clipboard, waking up a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie, a cute playful brown baby monkey character with big bright eyes, a curly tail and a stylish leafy fedora hat, and a cute plump green caterpillar character with big curious eyes, tiny yellow shoes and a cheerful yellow ribbon bow while a warm radiant golden sun character with a gentle smile, scholarly glasses and a bright golden bowtie rises brightly, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**Hành động:** Chị Lá cầm danh sách phân công điểm danh, đánh thức cả đội.
**Thoại:** Chị Lá (Thùy Dung, atempo cuối 0,7000) 125 ký tự, 8,23s, 15,19 k/t/s;
Tí (Thái Sơn, 0,7896) 104 ký tự, 6,92s, 15,03 k/t/s.
**Nhạc:** buổi sáng rộn ràng, tươi vui.
**⚠️ Soi clip:** đọc kỹ MỌI chữ trên clipboard checklist của Chị Lá — có chữ lạ thì sinh lại clip
(tiền lệ Tập 1 C10: đạo cụ checklist bị vẽ chữ “Checklogt”). Phom Tí giọt nước đơn cổ điển.

## Cảnh 2 — Tổ Kỹ Thuật Đất & Cát (27,16s)

**Prompt clip (EN, animatic + câu khóa):**
> Preparing the garden aisle, a friendly pink earthworm character wearing tiny round glasses and a cute pink bowtie aerates the soil, a small cute round desert beetle character with glossy golden-sand carapace covered in tiny dew-collecting bumps, miniature aviator goggles on forehead, dark brown boots, carrying a tiny gourd water canteen, expressive big eyes aligns glowing dew lanterns, a cute small Mars rover robot character with solar panel wings, six wheels and a friendly camera head measures straight lines with a laser beam, and a cute cheerful young mangrove sapling character with arched stilt roots as legs, glossy dark-green oval leaves, wearing a miniature Vietnamese conical hat (non la), bright friendly eyes stabilizes the wooden arch posts, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**Hành động:** Robot đo đạc, Cây Đước giữ trụ cổng, Giun Đất xới đất, Bọ xếp đèn sương.
**Thoại:** Robot (Quốc Tuấn, 0,7812) 97 k.tự; Cây Đước (Thục Đoan, 0,9516) 84;
Bọ (Thùy Dung, 0,7197) 93; Giun Đất (Thái Sơn, 0,9362) 80. Tốc độ 15,02–15,03 k/t/s.
**Nhạc:** vui tươi, nhịp lao động hăng say.

## Cảnh 3 — Sự cố treo ngược biển chữ Hỷ (28,74s)

**Prompt clip (EN, animatic + câu khóa):**
> High up on the floral wedding arch, a cute playful brown baby monkey character with big bright eyes, a curly tail and a stylish leafy fedora hat hangs upside down accidentally holding a 'Song Hy' banner upside down while a cute green tree frog character with very big red eyes, blue-yellow flank markings and orange toe pads, a cute plump green caterpillar character with big curious eyes, tiny yellow shoes and a cheerful yellow ribbon bow, and a cute tulip flower character with a red-pink tulip bloom head, green stem body and leaf arms laugh and point from below, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**Hành động:** Khỉ con treo lộn ngược biển Song Hỷ; Hoa Tulip + Sâu Xanh cười nhắc khéo.
**Thoại:** Hoa Tulip (Ngọc Linh, 0,8610) 89; Ếch (Minh Đức, 0,8643) 106;
Khỉ (Adam bựa, 0,8307) 87; Sâu Xanh (Đức Trí, 1,0254) 95. Tốc độ 14,94–15,03 k/t/s.
**Nhạc:** hài hước, tinh nghịch.
**⚠️ Soi clip — biển Song Hỷ:** hình AI làm biển ĐỎ KHÔNG CHỮ; kiểm tra khung hình không có chữ
do công cụ tự vẽ (kể cả chữ lộn ngược/méo). **Không ghép chữ thật** — để biển trống, lời thoại
đã nói rõ “chữ Song Hỷ” (quyết định dựng: biển trống an toàn hơn ghép chữ; ghi vào GHI_CHU).

## Cảnh 4 — Tổ Hậu Cần & Âm Nhạc (27,86s)

**Prompt clip (EN, animatic + câu khóa):**
> Carrying flower baskets and tuning wedding bells, a cute energetic baby zebra character with clear black-and-white stripes, a fluffy mane, bright eyes and a smart striped necktie trots beside a cute sandy-beige one-humped baby camel with a small brass bell at neck, long eyelashes and a desert scarf while a cute agile mountain goat kid character with tiny curved horns, sturdy hooves, wearing a wide cozy red knitted scarf and a cute fluffy white baby llama character with long ears and a gentle face arrange high terrace seating, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**Hành động:** Ngựa con phát thiệp mời, Lạc Đà con gõ chuông đồng, Sơn Dương + Llama sắp khán đài.
**Thoại:** Ngựa (Xuân Vĩnh, 0,7000) 108; Lạc Đà con (Thiền Tâm Đức, 0,9176) 84;
Sơn Dương (Thiện Minh, 0,7829) 94; Llama (Thái Sơn, 0,8356) 80. Tốc độ 15,01–15,25 k/t/s.
**Nhạc:** rộn rã, tiếng chuông đồng ngân vang.

## Cảnh 5 — Đội Băng Tuyết & Đại Dương (26,28s)

**Prompt clip (EN, animatic + câu khóa):**
> Around the central garden pond, a cute bright orange clownfish with thin white stripes along the back, big expressive eyes, wearing a tiny coral tiara, floating in a clear water bubble and a cute pink salmon character with cherry-blossom-pink scales swimming inside a water bubble blow shimmering water bubbles guided by a cute little sea turtle character with an ornate patterned turquoise-green shell and friendly flippers, while a cute chubby baby penguin character with soft fluffy ALL-GREY head and back, NOT black adult penguin head, wearing a long sea-blue knitted scarf and a small cute fluffy Arctic fox character with thick pure-white winter fur, tiny blue knitted scarf, round black nose, big warm amber eyes, stubby paws polish sparkling ice-crystal pedestals, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**Hành động:** Cá Nhỏ + Cá Hồi + Rùa Biển thổi bong bóng nước; Cánh Cụt + Cáo Tuyết tạo bệ băng pha lê.
**Thoại:** Cá Nhỏ (Ngọc Huyền, 0,7260) 92; Cá Hồi (Thùy Dung, 0,7000) 86;
Cáo Tuyết (Kim Thanh, 1,0451) 92; Cánh Cụt (Mai Anh, 0,8229) 74. Tốc độ 14,99–15,67 k/t/s.
**Nhạc:** trong trẻo, lấp lánh tiếng bong bóng nước.
**⚠️ Soi clip:** Cá Nhỏ MÀU CAM (chốt 27/11); Cánh Cụt đầu XÁM toàn đầu (không đầu đen),
khăn len xanh biển; Rùa Biển chỉ xuất hiện trong hình, KHÔNG thoại.

## Cảnh 6 — Tổ Ánh Sáng & Bầu Trời (23,39s)

**Prompt clip (EN, animatic + câu khóa):**
> In the sky above the garden, a warm radiant golden sun character with a gentle smile, scholarly glasses and a bright golden bowtie, a fluffy smiling white cloud character floating gently, wearing a tiny rainbow tiara and a soft white silk shawl, a cute small white rabbit character with soft fluffy white fur, long upright ears with pink inner ears, big round dark-brown eyes, rosy cheeks, a small pink nose and a cheerful smile, wearing a thin gold necklace with a golden crescent-moon pendant and shiny silver boots decorated with white stars and crescent moons, with a small fluffy white tail, and a cute nimble sparkling golden star-sprite character made of warm sunlight with a bright cheerful face, glowing ribbon trails, and tiny golden boots test rainbow sunbeams and silver moonlight sparkles over the wedding stage, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**Hành động:** Ông Mặt Trời + Tia Nắng Vàng chiếu tia nắng qua sương của Chị Mây + ánh trăng Thỏ Ngọc.
**Thoại:** Thỏ Ngọc (Đoan Trang, 0,8116) 101; Tia Nắng Vàng (Quỳnh Anh, 0,8411) 104;
Chị Mây (Mỹ Duyên, 1,0641) 98. Tốc độ 14,97–15,03 k/t/s.
**Nhạc:** kỳ ảo, lung linh.
**⚠️ Soi clip:** Ông Mặt Trời chỉ xuất hiện trong hình, KHÔNG thoại. Cận Cánh Cụt không có ở cảnh này;
nhưng lưu ý chung: cận nhân vật nên dùng ánh sáng sáng để màu đọc đúng.

## Cảnh 7 — CẢNH ĂN TIỀN: Tổng duyệt lễ đường (20,00s = góc 1: 10s + góc 2: 10s)

**Hành động:** Tất cả 25 nhân vật bật sáng toàn bộ lễ đường thiên nhiên (Đất – Nước – Rừng – Vũ Trụ).
**Thoại:** Bác Rễ (Adam, 0,7000) 123 ký tự, 7,61s, 16,16 k/t/s;
Cây Ô Liu (Phạm Tuyên, 0,7727) 110 ký tự, 7,32s, 15,04 k/t/s.
**Nhạc:** hoành tráng, ấm áp, vỡ òa tự hào.

### Góc 1 — Toàn cảnh pan (10s)

**Prompt clip (EN — animatic + câu khóa chống khán giả người, theo lệnh dựng):**
> Grand evening rehearsal in the illuminated magical garden where all 25 characters stand together admiring the completed nature wedding cathedral: glowing dew lanterns, floral arches, floating rainbow water bubbles, ice-crystal pedestals, and a shimmering rainbow canopy cast by a warm radiant golden sun character with a gentle smile, scholarly glasses and a bright golden bowtie, a fluffy smiling white cloud character floating gently, wearing a tiny rainbow tiara and a soft white silk shawl, a cute small white rabbit character with soft fluffy white fur, long upright ears with pink inner ears, big round dark-brown eyes, rosy cheeks, a small pink nose and a cheerful smile, wearing a thin gold necklace with a golden crescent-moon pendant and shiny silver boots decorated with white stars and crescent moons, with a small fluffy white tail, and a cute nimble sparkling golden star-sprite character made of warm sunlight with a bright cheerful face, glowing ribbon trails, and tiny golden boots, with a wise old brown tree-root character with longer silver-streaked root beard, round spectacles, kind eyes and earthy tendrils and a cute ancient olive tree character with a gnarled brown trunk, kind old face and silvery-green olive leaves beaming proudly, wide panoramic shot, camera slowly pans left to right across all 25 characters, 3D Pixar-style animation. Only these 25 characters, no other people, no human audience in the background. Absolutely no numbers, no digits, no text, no letters, no watermarks.

### Góc 2 — Cận nhóm (10s)

**Prompt clip (EN — cận nhóm, tập trung 2 nhân vật thoại + 2 cặp từng vắng ở Tập 1):**
> Close-up at the grand evening rehearsal in the illuminated magical garden: a wise old brown tree-root character with longer silver-streaked root beard, round spectacles, kind eyes and earthy tendrils and a cute ancient olive tree character with a gnarled brown trunk, kind old face and silvery-green olive leaves beaming proudly in the foreground, with a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie and a vibrant cheerful green leaf character with big expressive eyes, tiny arms and legs, wearing a white pomelo-blossom hairclip beside them, and a cute little sea turtle character with an ornate patterned turquoise-green shell and friendly flippers with a cute pink salmon character with cherry-blossom-pink scales swimming inside a water bubble, and a cute playful brown baby monkey character with big bright eyes, a curly tail and a stylish leafy fedora hat with a cute green tree frog character with very big red eyes, blue-yellow flank markings and orange toe pads smiling clearly nearby, glowing dew lanterns, floral arches and floating rainbow water bubbles behind, 3D Pixar-style animation. Only these 8 characters, no other people, no human audience in the background. Absolutely no numbers, no digits, no text, no letters, no watermarks.

### Bảng roster 2 góc quay C7 (bắt buộc đối chiếu từng nhân vật — bài học Tập 1)

10 cặp cưới: Tí–Cá Nhỏ · Cánh Cụt–Cáo Tuyết · Sơn Dương–Llama · Ngựa–Lạc Đà · Khỉ–Ếch ·
Rùa Biển–Cá Hồi · Sâu Xanh–Hoa Tulip · Giun Đất–Bọ · Thỏ Ngọc–Tia Nắng Vàng · Robot–Cây Đước.
5 nhân vật ngoài cặp: Chị Lá · Bác Rễ · Cây Ô Liu · Ông Mặt Trời · Chị Mây. Tổng 25.

| # | Nhân vật | Cặp/nhóm | Góc 1 (pan) — mặt rõ? | Góc 2 (cận) — mặt rõ? | Ghi chú kiểm tra |
|---|---|---|---|---|---|
| 1 | Tí | Tí–Cá Nhỏ | ☐ | ☑ (cận, cạnh Chị Lá) | Phom giọt nước đơn |
| 2 | Cá Nhỏ | Tí–Cá Nhỏ | ☐ | ☐ (kiểm tra khi soi keyframe) | MÀU CAM |
| 3 | Chim Cánh Cụt con | Cánh Cụt–Cáo Tuyết | ☐ | ☐ | Đầu XÁM toàn đầu |
| 4 | Cáo Tuyết Bắc Cực | Cánh Cụt–Cáo Tuyết | ☐ | ☐ | |
| 5 | Sơn Dương con | Sơn Dương–Llama | ☐ | ☐ | |
| 6 | Lạc Đà Llama | Sơn Dương–Llama | ☐ | ☐ | |
| 7 | Ngựa con | Ngựa–Lạc Đà | ☐ | ☐ | Ngựa vằn sọc rõ |
| 8 | Lạc Đà con | Ngựa–Lạc Đà | ☐ | ☐ | Một bướu + chuông đồng |
| 9 | Khỉ con | Khỉ–Ếch | ☐ | ☑ (cận, cạnh Ếch) | Cặp từng vắng ở Tập 1 |
| 10 | Ếch Cây Mắt Đỏ | Khỉ–Ếch | ☐ | ☑ (cận, cạnh Khỉ) | Cặp từng vắng ở Tập 1 |
| 11 | Rùa Biển con | Rùa–Cá Hồi | ☐ | ☑ (cận, cạnh Cá Hồi) | Cặp từng VẮNG HOÀN TOÀN ở Tập 1 |
| 12 | Cá Hồi Hoa Anh Đào | Rùa–Cá Hồi | ☐ | ☑ (cận, cạnh Rùa) | Cặp từng VẮNG HOÀN TOÀN ở Tập 1 |
| 13 | Sâu Xanh | Sâu–Hoa Tulip | ☐ | ☐ | |
| 14 | Hoa Tulip | Sâu–Hoa Tulip | ☐ | ☐ | |
| 15 | Giun Đất | Giun–Bọ | ☐ | ☐ | |
| 16 | Bọ Cánh Cứng Cát | Giun–Bọ | ☐ | ☐ | |
| 17 | Thỏ Ngọc | Thỏ–Tia Nắng | ☐ | ☐ | |
| 18 | Tia Nắng Vàng | Thỏ–Tia Nắng | ☐ | ☐ | |
| 19 | Robot Thám Hiểm | Robot–Cây Đước | ☐ | ☐ | |
| 20 | Cây Đước Ngập Mặn | Robot–Cây Đước | ☐ | ☐ | Nón lá |
| 21 | Chị Lá | (ngoài cặp) | ☐ | ☑ (cận, cạnh Tí) | |
| 22 | Bác Rễ | (ngoài cặp, thoại C7) | ☐ | ☑ (cận, trung tâm) | Nhân vật thoại |
| 23 | Cây Ô Liu Cổ Thụ | (ngoài cặp, thoại C7) | ☐ | ☑ (cận, trung tâm) | Nhân vật thoại |
| 24 | Ông Mặt Trời | (ngoài cặp) | ☐ | ☐ | Mặt đỏ-cam, râu vàng |
| 25 | Chị Mây | (ngoài cặp) | ☐ | ☐ | Khăn cầu vồng nhỏ |

**Tiêu chí ĐẠT C7 (bắt buộc):** mỗi nhân vật có mặt rõ ở ít nhất 1 trong 2 góc; mỗi cặp/nhóm
có ít nhất một khung mặt rõ cả hai; nền KHÔNG có khán giả người (soi cả nền khi pan quét qua);
không thêm/bớt/đổi nhân vật. Cặp nào vắng ở góc 1 phải rõ mặt ở góc 2 — nếu cả 2 góc đều
không rõ thì sinh lại clip góc đó (không chấp nhận “có mặt trong cảnh” chung chung).

## Cảnh 8 — Bài học Sinh học (20,54s)

**Prompt clip (EN, animatic + câu khóa):**
> a wise old brown tree-root character with longer silver-streaked root beard, round spectacles, kind eyes and earthy tendrils and a vibrant cheerful green leaf character with big expressive eyes, tiny arms and legs, wearing a white pomelo-blossom hairclip showing a glowing 3D holographic diagram of mutualism and cooperation in ecosystems to a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie and the cheerful group, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**Hành động:** Bác Rễ + Chị Lá chỉ ra bí quyết: cộng sinh + hợp tác như trong tự nhiên.
**Thoại:** Bác Rễ (Adam, 0,7218) 158 ký tự, 10,52s, 15,02 k/t/s (lượt mới);
Chị Lá (Thùy Dung, 0,7000) 113 ký tự, 7,23s, 15,64 k/t/s (lượt mới).
**Nhạc:** khám phá khoa học nhẹ nhàng.
**⚠️ Soi clip:** sơ đồ hologram 3D KHÔNG được có chữ/số do công cụ tự vẽ (câu khóa no-text);
nếu sơ đồ có chữ lạ thì sinh lại clip.

## Cảnh 9 — Ghi chép sổ tay (20,00s)

**Prompt clip (EN, animatic + câu khóa):**
> a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie writing in his glowing holographic notebook beside a cute bright orange clownfish with thin white stripes along the back, big expressive eyes, wearing a tiny coral tiara, floating in a clear water bubble under the twinkling dew lanterns at night, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**Hành động:** Tí ghi thông điệp + kiến thức Sinh học 12 vào sổ tay trước đêm trọng đại.
**Thoại:** Tí (Thái Sơn, 0,9285) 233 ký tự, 15,53s, 15,00 k/t/s (lượt mới, độc thoại dài nhất tập).
**Nhạc:** sâu lắng, ấm áp.
**⚠️ Soi clip:** đọc kỹ MỌI chữ trên trang sổ tay — có chữ lạ thì sinh lại clip. Cá Nhỏ MÀU CAM.
Phom Tí giọt nước đơn — soi DỌC toàn bộ clip (tiền lệ Tập 1: morph hai tầng chỉ ~2–4s ở C10).

## Cảnh 10 — Hẹn gặp Tập 3 & Lời chúc chuẩn (20,11s)

**Prompt clip (EN — ĐÃ SỬA theo lệnh Thầy: bỏ “Biology 12 textbook”, thay bằng sách tranh KHÔNG chữ):**
> a cute translucent blue water droplet character with big round expressive eyes, rosy cheeks, tiny arms and legs, wearing a neat miniature sky-blue bowtie, a cute bright orange clownfish with thin white stripes along the back, big expressive eyes, wearing a tiny coral tiara, floating in a clear water bubble, and a cute ancient olive tree character with a gnarled brown trunk, kind old face and silvery-green olive leaves waving beside a glowing golden wedding invitation for Episode 3 and an open picture book with leaf and cell diagrams, no words, 3D Pixar-style animation. Absolutely no numbers, no digits, no text, no letters, no watermarks.

**Hành động:** Tí + Cá Nhỏ + Cây Ô Liu giơ thiệp mời, vẫy tay chào khán giả + lời chúc của Thầy.
**Thoại:** Tí (Thái Sơn, 0,9199) 224 ký tự, 14,92s, 15,01 k/t/s (lượt mới);
Thầy (Thái Sơn, 0,7929) 37 ký tự, 2,44s, 15,16 k/t/s — nghỉ 0,35s giữa 2 lượt (cùng giọng Thái Sơn),
Thầy voice-over, không có hình trong prompt.
**Nhạc:** outro vui tươi, tiếng chuông thông báo.
**⚠️ Soi clip:** thiệp mời vàng + sách tranh KHÔNG được có chữ do công cụ tự vẽ (đặc biệt chữ tiếng Anh
“Biology”/“Checklogt” kiểu Tập 1 C10); Cá Nhỏ MÀU CAM; phom Tí giọt nước đơn — soi DỌC toàn bộ clip.

---

## Thẻ kết (10,00s — chuẩn Mùa 3 theo tập mẫu)

- Khung tĩnh = ảnh C7 góc 2 làm tối + **3 dòng chữ căn giữa, tiếng Việt đúng chính tả**:
  “CẢM ƠN CÁC BẠN ĐÃ XEM!” (trắng, đậm, lớn) /
  “Giọt Nước Tí — Mùa 3: Cưới Nhau” (vàng nhạt, đậm) /
  “Hẹn gặp lại ở Tập 3: Đám Cưới Liên Hoàn Rộn Rã Tại Khu Vườn Kỳ Diệu nhé!” (trắng, đậm).
- **Chữ ký VẪN ở góc phải trên, KHÔNG căn giữa** (khác quy tắc Vòng 2/3).
- Âm thanh: nhạc nền không lời, yên hơn hẳn phần phim (tập mẫu: −28,4 dB).

## Thumbnail (1280×720)

- Ảnh C7 (góc 2, hoặc khung đẹp nhất C7) + chữ vàng lớn “CƯỚI NHAU” (trên) +
  chữ trắng “Tập 2 — Tất Bật Chuẩn Bị Đám Cưới Liên Hoàn” (dưới), tiếng Việt đúng chính tả.

## Checklist nghiệm thu 2 lớp (trước khi báo xong)

**(a) Soi mắt từng cảnh:** mặt rõ từng cặp/nhóm C7 (bảng roster trên) · phom Tí giọt đơn dọc toàn bộ clip
(C1/C9/C10) · Cá Nhỏ cam (C5/C9/C10) · chữ trên đạo cụ (clipboard C1, biển C3, sơ đồ C8,
sổ tay C9, thiệp + sách C10) — không chữ lạ · chữ ký vàng kem góc phải trên suốt phần phim + thẻ kết ·
thẻ kết đúng 3 dòng tiếng Việt + chữ ký góc phải trên.
**(b) Đo máy:** ffprobe 1920×1080 30fps AAC 48kHz mono · freezedetect (cảnh chính không đứng hình > 2s,
chỉ thẻ kết được đứng) · silencedetect (không khoảng lặng > 3s) · loudnorm I ≈ −15,5 ·
thoại bắt đầu ở mốc 0,8s đầu mỗi đoạn (xem bảng thời lượng).
