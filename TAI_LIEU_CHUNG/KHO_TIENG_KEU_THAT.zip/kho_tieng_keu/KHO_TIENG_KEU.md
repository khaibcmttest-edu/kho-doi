# KHO TIẾNG KÊU THẬT — Series Giọt Nước Tí

Kho tiếng kêu/tiếng động thật cho phim Giọt Nước Tí, lập ngày 27/11/2026 theo lệnh thầy Khải.
Nguyên tắc bản quyền: chỉ dùng âm thanh miễn phí có giấy phép rõ ràng (CC0, Public domain, CC BY, CC BY-SA — đều cho phép dùng thương mại), ghi nguồn + giấy phép từng file. Không dùng file không rõ nguồn, không tự chế bằng TTS.

Chuẩn file: WAV PCM 48 kHz stereo, đoạn kêu rõ nhất 2–6 giây, đã chuẩn hoá loudnorm I=-16.

## Đã có tiếng (20 file / 19 nhân vật)

| Nhân vật | Tiếng trong kịch bản | Tên file | Thời lượng | Nguồn | Giấy phép |
|---|---|---|---|---|---|
| Bác Rễ (cây) | hmm-hmm — tiếng cây cựa mình trầm ấm | `bac_re_cay_cua.wav` | 6.0s | [trang nguồn](https://archive.org/details/aporee_17590_20468) · [link tải gốc](https://archive.org/download/aporee_17590_20468/podrtoDrevo24april201317091.mp3) | Public Domain Mark 1.0 |
| Chị Lá (lá) | rustle-rustle — tiếng lá xào xạc | `chi_la_xao_xac.wav` | 6.0s | [trang nguồn](https://archive.org/details/mjchesneyRustlingLeaves_0) · [link tải gốc](https://archive.org/download/mjchesneyRustlingLeaves_0/RustlingLeaves.mp3) | CC BY 2.5 |
| Hoa Tulip | chime-chime — tiếng chuông gió | `hoa_tulip_chuong_gio.wav` | 6.0s | [trang nguồn](https://archive.org/details/aporee_35404_40663) · [link tải gốc](https://archive.org/download/aporee_35404_40663/WindChimesBusStop73rdDitmars.mp3) | Public Domain Mark 1.0 |
| Cá Nhỏ (cá hề) | blub-blub — tiếng bong bóng dưới nước | `ca_nho_bong_bong.wav` | 6.0s | [trang nguồn](https://archive.org/details/bubblessoundeffects) · [link tải gốc](https://archive.org/download/bubblessoundeffects/fbrj1-nmycb.mp3) | CC0 1.0 |
| Rùa Biển con | splash-splash — tiếng vỗ nước | `rua_bien_vo_nuoc.wav` | 2.1s | [trang nguồn](https://commons.wikimedia.org/wiki/File:Bathtub_water_splashes.ogg) · [link tải gốc](https://upload.wikimedia.org/wikipedia/commons/8/83/Bathtub_water_splashes.ogg) | Public domain |
| Cây Đước Ngập Mặn | whoosh-whoosh — gió mạnh qua tán cây | `cay_duoc_gio.wav` | 6.0s | [trang nguồn](https://archive.org/details/aporee_72116_84218) · [link tải gốc](https://archive.org/download/aporee_72116_84218/IledesainteLuciestrongwind.mp3) | Public Domain Mark 1.0 |
| Khỉ con | ooh-ooh-ah-ah — tiếng khỉ con kêu (tiếng kêu đơn 1,84s lặp 2 lần) | `khi_con.wav` | 3.7s | [trang nguồn](https://archive.org/details/various-animal-sounds) · [link tải gốc](https://archive.org/download/various-animal-sounds/mixkit-little-monkey-screech-104.wav) | CC0 1.0 (theo metadata Internet Archive; file gốc Mixkit) |
| Ếch Cây Mắt Đỏ | ribbit-ribbit — tiếng ếch cây kêu | `ech_cay_ribbit.wav` | 6.0s | [trang nguồn](https://archive.org/details/various-animal-sounds) · [link tải gốc](https://archive.org/download/various-animal-sounds/pacific-treefrogs-in-mating-season-22817.mp3) | CC0 1.0 (theo metadata Internet Archive) |
| Ngựa con (ngựa vằn) | neigh-neigh — tiếng ngựa hí (tiếng hí đơn 1,9s lặp 2 lần) | `ngua_con_hi.wav` | 3.8s | [trang nguồn](https://archive.org/details/SSE_Library_ANIMALS) · [link tải gốc](https://archive.org/download/SSE_Library_ANIMALS/HORSE/ANMLHors_Classic%20horse%20whinny_CS_USC.mp3) | CC0 1.0 |
| Ngựa con (ngựa vằn) | tiếng vó ngựa phi trên đất | `ngua_con_vo.wav` | 6.0s | [trang nguồn](https://archive.org/details/SSE_Library_ANIMALS) · [link tải gốc](https://archive.org/download/SSE_Library_ANIMALS/HORSE/ANMLHors_Foley%20horse%20gallops%20by%3B%20dirt_CS_USC.mp3) | CC0 1.0 |
| Cá Hồi Hoa Anh Đào | splish-splash — tiếng nước bắn khi cá nhảy (tiếng nước thật; chưa có bản ghi cá nhảy riêng) | `ca_hoi_splash.wav` | 5.0s | [trang nguồn](https://commons.wikimedia.org/wiki/File:Bathtub_water_splashes.ogg) · [link tải gốc](https://upload.wikimedia.org/wikipedia/commons/8/83/Bathtub_water_splashes.ogg) | Public domain |
| Sơn Dương con (dê núi) | baa-baa — tiếng dê con kêu (tiếng kêu đơn 0,58s lặp 4 lần) | `son_duong_baa.wav` | 2.3s | [trang nguồn](https://archive.org/details/various-animal-sounds) · [link tải gốc](https://archive.org/download/various-animal-sounds/mixkit-baby-goat-baa-1764.wav) | CC0 1.0 (theo metadata Internet Archive; file gốc Mixkit) |
| Cây Ô Liu Cổ Thụ | shhh-rustle — gió lùa qua lá/sậy | `cay_o_liu_gio_la.wav` | 6.0s | [trang nguồn](https://archive.org/details/aporee_65433_75640) · [link tải gốc](https://archive.org/download/aporee_65433_75640/koosGreifswald071020240941.mp3) | CC BY-SA 3.0 |
| Lạc Đà con | grunt-grunt — tiếng lạc đà khục kêu | `lac_da_grunt.wav` | 6.0s | [trang nguồn](https://archive.org/details/GOLD_TAPE_12_Animals) · [link tải gốc](https://archive.org/download/GOLD_TAPE_12_Animals/G12-05-Camel%20Grunt.wav) | CC0 1.0 |
| Bọ Cánh Cứng Cát | buzz-buzz — tiếng cánh côn trùng vỗ (bản ghi tiếng ong vỗ cánh) (tiếng buzz đơn 1,48s lặp 2 lần) | `bo_canh_cung_buzz.wav` | 3.0s | [trang nguồn](https://archive.org/details/various-animal-sounds) · [link tải gốc](https://archive.org/download/various-animal-sounds/mixkit-bumblebee-short-buzz-329.wav) | CC0 1.0 (theo metadata Internet Archive; file gốc Mixkit) |
| Chim Cánh Cụt con | peep-peep — tiếng chim cánh cụt nhỏ kêu | `canh_cut_peep.wav` | 6.0s | [trang nguồn](https://commons.wikimedia.org/wiki/File:20091121_Little_Penguin_calls_at_St_Kilda_Breakwater.ogg) · [link tải gốc](https://upload.wikimedia.org/wikipedia/commons/5/5a/20091121_Little_Penguin_calls_at_St_Kilda_Breakwater.ogg) | CC BY 3.0 |
| Cáo Tuyết | yip-yip — tiếng cáo kêu/sủa nhỏ (bản ghi cáo đô thị) | `cao_tuyet_yip.wav` | 6.0s | [trang nguồn](https://archive.org/details/various-animal-sounds) · [link tải gốc](https://archive.org/download/various-animal-sounds/urban-fox-call-26795.mp3) | CC0 1.0 (theo metadata Internet Archive) |
| Chị Mây | poof-whoosh — tiếng gió mạnh | `chi_may_gio.wav` | 6.0s | [trang nguồn](https://archive.org/details/aporee_60944_75699) · [link tải gốc](https://archive.org/download/aporee_60944_75699/kirchmoeserAngerGarden101020241008.mp3) | CC BY-SA 3.0 |
| Tia Nắng Vàng | sparkle-zing — hiệu ứng lấp lánh (nhân vật giả tưởng) | `tia_nang_sparkle.wav` | 6.0s | [trang nguồn](https://commons.wikimedia.org/wiki/File:Easy_sparkle_(Gravity_Sound).wav) · [link tải gốc](https://upload.wikimedia.org/wikipedia/commons/3/3c/Easy_sparkle_%28Gravity_Sound%29.wav) | CC BY 4.0 |
| Robot Thám Hiểm | beep-boop — tiếng beep điện tử (nhân vật giả tưởng) (tiếng beep đơn 0,99s lặp 3 lần) | `robot_beep.wav` | 3.0s | [trang nguồn](https://commons.wikimedia.org/wiki/File:Beep-09.ogg) · [link tải gốc](https://upload.wikimedia.org/wikipedia/commons/0/05/Beep-09.ogg) | CC BY-SA 4.0 |

## Chưa có tiếng (4 nhân vật)

| Nhân vật | Tiếng cần | Lý do chưa có |
|---|---|---|
| Sâu Xanh | munch-munch — sâu nhai lá | Chưa tìm được bản ghi miễn phí rõ giấy phép trên Wikimedia Commons / Internet Archive |
| Giun Đất | squish-squish — giun trườn qua đất ẩm | Chưa tìm được bản ghi miễn phí rõ giấy phép |
| Llama | mwah-hum — llama ngân | Chưa tìm được bản ghi llama/alpaca hum miễn phí rõ giấy phép (các file tìm thấy đều là phát âm từ hoặc không ghi giấy phép) |
| Ông Mặt Trời | hum-shine — tiếng ngân ấm áp | Nhân vật giả tưởng, không có tiếng thật trong tự nhiên; chưa chọn hiệu ứng thay thế |

## Ghi chú khi dùng

- Cá Hồi (`ca_hoi_splash.wav`): tiếng nước bắn thật dùng cho cảnh cá nhảy — chưa có bản ghi cá nhảy riêng.
- Bọ Cánh Cứng Cát (`bo_canh_cung_buzz.wav`): bản ghi tiếng ong vỗ cánh dùng làm tiếng cánh côn trùng.
- Cáo Tuyết (`cao_tuyet_yip.wav`): bản ghi cáo đô thị (cáo đỏ) kêu — gần với tiếng cáo tuyết sủa nhỏ.
- Chim Cánh Cụt con (`canh_cut_peep.wav`): bản ghi chim cánh cụt nhỏ (little penguin) kêu.
- Tia Nắng Vàng + Robot: nhân vật giả tưởng, dùng hiệu ứng sparkle/beep ghi âm thật, giấy phép CC BY/CC BY-SA — khi đăng video nhớ ghi nguồn theo giấy phép nếu cần.
- File có giấy phép CC BY / CC BY-SA: khi dùng trong video đăng công khai, ghi nguồn ở mô tả video theo yêu cầu giấy phép.
- File gốc tải về lưu ở `work/raw/`, script xử lý ở `work/process.py`, danh sách nguồn ở `work/sources.json`.
