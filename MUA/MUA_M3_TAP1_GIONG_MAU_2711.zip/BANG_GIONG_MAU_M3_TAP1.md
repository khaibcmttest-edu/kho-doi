# BẢNG GIỌNG MẪU — MÙA 3 TẬP 1 (KHOÁ KHUNG BƯỚC 2)

Mỗi nhân vật 1 file WAV lồng thử **đúng câu thoại của nhân vật trong kịch bản Tập 1**, giọng + hệ số tốc độ (atempo) theo **Bảng giọng VieNeu chuẩn toàn series** (Thầy chốt 26/11/2026). Tốc độ đo thực tế trên bản mẫu; khi dựng thật, từng câu sẽ được chỉnh atempo trong khoảng 0,7–1,1 để về quanh chuẩn ~15 ký tự/giây.

| # | Nhân vật | Giọng VieNeu | atempo | File mẫu | Dài | Ký tự/giây đo được |
|---|---|---|---|---|---|---|
| 1 | Giọt Nước Tí | Thái Sơn | 0,90 | ti.wav | 6,74s | 14,8 |
| 2 | Bác Rễ | Adam | 0,794 | bac_re.wav | 6,94s | 14,3 |
| 3 | Cây Ô Liu Cổ Thụ | Phạm Tuyên | 0,80 | cay_o_liu.wav | 7,59s | 14,9 |
| 4 | Hoa Tulip | Ngọc Linh | 0,85 | hoa_tulip.wav | 6,48s | 16,2 |
| 5 | Sâu Xanh | Đức Trí | 0,85 | sau_xanh.wav | 9,31s | 10,8 (giọng chậm — khi dựng tăng atempo nhẹ) |
| 6 | Khỉ con | Adam (bựa) | 0,90 | khi_con.wav | 6,12s | 18,1 (hơi nhanh — khi dựng giảm nhẹ) |
| 7 | Ếch Cây Mắt Đỏ | Minh Đức | 0,85 | ech_cay.wav | 5,35s | 15,3 |
| 8 | Cáo Tuyết Bắc Cực | Kim Thanh | 0,85 | cao_tuyet.wav | 7,99s | 10,9 (giọng chậm — khi dựng tăng atempo nhẹ) |
| 9 | Chim Cánh Cụt con | Mai Anh | 0,85 | canh_cut.wav | 6,01s | 14,5 |
| 10 | Sơn Dương con | Thiện Minh | 0,85 | son_duong.wav | 6,48s | 15,1 |
| 11 | Lạc Đà Llama | Thái Sơn | 0,85 | llama.wav | 6,67s | 13,6 |
| 12 | Ngựa con | Xuân Vĩnh | 0,90 | ngua_con.wav | 5,59s | 17,9 (hơi nhanh — khi dựng giảm nhẹ) |
| 13 | Lạc Đà con | Thiền Tâm Đức | 0,80 | lac_da_con.wav | 7,69s | 10,9 (giọng chậm — khi dựng tăng atempo nhẹ) |
| 14 | Rùa Biển con | Thanh Bình | 0,80 | rua_bien.wav | 5,68s | 19,7 (câu có dấu "..." — máy đọc ít ngừng; khi dựng sẽ chèn khoảng lặng tay để giữ nhịp chậm rãi của nhân vật) |
| 15 | Cá Hồi Hoa Anh Đào | Thùy Dung | 0,85 | ca_hoi.wav | 5,45s | 17,3 |
| 16 | Bọ Cánh Cứng Cát | Thùy Dung | 0,739 | bo_canh_cung.wav | 5,94s | 15,5 |
| 17 | Giun Đất | Thái Sơn | 0,95 | giun_dat.wav | 5,38s | 16,2 |
| 18 | Thỏ Ngọc | Đoan Trang | 0,85 | tho_ngoc.wav | 5,82s | 15,6 |
| 19 | Tia Nắng Vàng | Quỳnh Anh | 0,85 | tia_nang_vang.wav | 4,79s | 15,0 |
| 20 | Robot Thám Hiểm | Quốc Tuấn | 0,85 | robot.wav | 5,07s | 16,0 |
| 21 | Cây Đước Ngập Mặn | Thục Đoan | 0,85 | cay_duoc.wav | 6,11s | 13,9 |
| 22 | Cá Nhỏ | Ngọc Huyền | 0,85 | ca_nho.wav | 6,67s | 15,9 |
| 23 | Chị Lá | Thùy Dung | 0,739 | chi_la.wav | 6,59s | 14,6 |
| 24 | Ông Mặt Trời | Minh Triết | 0,814 | ong_mat_troi.wav | 6,29s | 16,2 |
| 25 | Chị Mây | Mỹ Duyên | 0,85 | chi_may.wav | 5,73s | 12,9 |
| 26 | Thầy Hồ Tấn Khải (lời chúc cuối tập) | Thái Sơn | 0,95 | thay.wav | 2,18s | 17,0 |

**Ghi chú trùng giọng (theo đúng bảng chuẩn + kịch bản):** Thái Sơn đảm nhận 4 vai (Tí 0,90 · Llama 0,85 · Giun Đất 0,95 · Thầy 0,95) và Thùy Dung 3 vai (Cá Hồi 0,85 · Bọ Cánh Cứng 0,739 · Chị Lá 0,739), Adam 2 vai (Bác Rễ 0,794 · Khỉ con 0,90) — phân biệt bằng hệ số tốc độ và ngữ cảnh cảnh; Đạo diễn nghe mẫu thấy chưa tách bạch thì cho ý kiến, em chỉnh trước khi dựng.
