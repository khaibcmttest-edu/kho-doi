# Mùa 3 "Cưới Nhau" — Tập 1: Khóa khung BƯỚC 1(a) — Hình chuẩn "trưởng thành" 25/25 nhân vật

- Tập: Mùa 3 Tập 1 "Khi Cả Đội Lớn Lên & Màn Cầu Hôn Có Một Không Hai" (kịch bản Kill, TAI_LIEU_CHUNG/KICH_BAN_MUA3_CUOI_NHAU_KILL.docx)
- Người nộp: Mưa — ngày 27/11/2026 (lượt 17:09)
- Gồm 25 hình chuẩn, mỗi nhân vật 1 ảnh riêng, toàn thân, nền trơn sáng, phong cách 3D Pixar-style, không chữ không số. Mô tả theo đúng prompt kịch bản Tập 1 (Cảnh 1–10); giữ nguyên tạo hình gốc, chỉ thêm phụ kiện trưởng thành.
- File ONG_MAT_TROI_TRUONG_THANH_V1_CO_NON.webp (bản v1 lỗi) KHÔNG nộp — chỉ nộp bản v2 ONG_MAT_TROI_TRUONG_THANH.webp.

## Danh sách 25 hình (tên file — mô tả khoá EN theo kịch bản)
1. TI_TRUONG_THANH.webp — translucent blue water droplet, big round eyes, rosy cheeks, neat miniature sky-blue bowtie
2. CA_NHO_TRUONG_THANH.webp — bright ORANGE clownfish, thin white stripes, big eyes, tiny coral tiara, floating in a clear water bubble (MÀU CAM theo chốt Thầy 06:26 ngày 27/11 — không dùng hồng đào cũ)
3. BAC_RE_TRUONG_THANH.webp — wise old brown tree-root, longer silver-streaked root beard, round spectacles, kind eyes
4. CAY_O_LIU_TRUONG_THANH.webp — ancient olive tree, gnarled brown trunk, kind old face, silvery-green olive leaves
5. ONG_MAT_TROI_TRUONG_THANH.webp — warm radiant golden sun, gentle smile, scholarly glasses, bright golden bowtie
6. CHI_MAY_TRUONG_THANH.webp — fluffy white cloud, tiny rainbow tiara, soft white silk shawl
7. CHI_LA_TRUONG_THANH.webp — vibrant green leaf, big expressive eyes, white pomelo-blossom hairclip
8. KHI_CON_TRUONG_THANH.webp — playful brown baby monkey, big bright eyes, curly tail, stylish leafy fedora hat
9. ECH_CAY_TRUONG_THANH.webp — green tree frog, very big red eyes, blue-yellow flank markings, orange toe pads
10. SAU_XANH_TRUONG_THANH.webp — plump green caterpillar, big curious eyes, tiny yellow shoes, cheerful yellow ribbon bow
11. HOA_TULIP_TRUONG_THANH.webp — tulip flower, red-pink tulip bloom head, green stem body and leaf arms
12. CANH_CUT_TRUONG_THANH.webp — chubby baby emperor penguin, soft fluffy ALL-GREY head and back (NOT black adult head), long sea-blue knitted scarf
13. CAO_TUYET_TRUONG_THANH.webp — fluffy Arctic fox, thick pure-white winter fur, tiny blue knitted scarf, round black nose, big warm amber eyes
14. SON_DUONG_TRUONG_THANH.webp — agile mountain goat kid, tiny curved horns, sturdy hooves, wide cozy red knitted scarf
15. LLAMA_TRUONG_THANH.webp — fluffy white baby llama, long ears, gentle face
16. NGUA_TRUONG_THANH.webp — energetic baby zebra, clear black-and-white stripes, fluffy mane, bright eyes, smart striped necktie
17. LAC_DA_TRUONG_THANH.webp — sandy-beige one-humped baby camel, small brass bell at neck, long eyelashes, desert scarf
18. RUA_BIEN_TRUONG_THANH.webp — little sea turtle, ornate patterned turquoise-green shell, friendly flippers
19. CA_HOI_TRUONG_THANH.webp — pink salmon, cherry-blossom-pink scales, swimming inside a water bubble
20. GIUN_DAT_TRUONG_THANH.webp — friendly pink earthworm, tiny round glasses, cute pink bowtie
21. BO_CANH_CUNG_TRUONG_THANH.webp — round desert beetle, glossy golden-sand carapace with dew-collecting bumps, miniature aviator goggles, dark brown boots, tiny gourd water canteen
22. THO_NGOC_TRUONG_THANH.webp — small white rabbit, fluffy white fur, long upright ears with pink inner ears, gold necklace with golden crescent-moon pendant, shiny silver boots with white stars and crescent moons
23. TIA_NANG_VANG_TRUONG_THANH.webp — nimble sparkling golden star-sprite, warm sunlight, bright cheerful face, glowing ribbon trails, tiny golden boots
24. ROBOT_TRUONG_THANH.webp — small Mars rover robot, solar panel wings, six wheels, friendly camera head
25. CAY_DUOC_TRUONG_THANH.webp — cheerful young mangrove sapling, arched stilt roots as legs, glossy dark-green oval leaves, miniature Vietnamese conical hat (non la)

## Tự kiểm của Mưa trước khi nộp
- Đủ 25/25 file, đúng tên, đúng định dạng .webp.
- Soi mắt 6 hình rủi ro cao: Tí (nơ xanh da trời), Chị Mây (vương miện cầu vồng + khăn lụa), Cá Nhỏ (CAM, vương miện san hô, bong bóng nước — đúng chốt), Cánh Cụt (đầu XÁM BÔNG toàn đầu, khăn len xanh biển — không đầu đen), Cây Đước (rễ chống làm chân + nón lá), Tia Nắng Vàng (ngôi sao vàng, dải ruy-băng sáng, ủng vàng) — đều khớp mô tả khoá.
- 19 hình còn lại kiểm theo tên file + dung lượng (mỗi file 139–444 KB); chờ Đạo diễn duyệt độc lập.
- Nhờ Đạo diễn duyệt bước 1(a): nếu đạt, em làm tiếp bước 1(b) giọng mẫu rồi bước 1(c) animatic; chưa dựng thật khi chưa duyệt đủ 3 bước.
