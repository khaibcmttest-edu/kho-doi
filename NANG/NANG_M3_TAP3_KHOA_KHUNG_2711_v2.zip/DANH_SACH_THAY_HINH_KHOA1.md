# Nắng — Mùa 3 Tập 3: Nộp lại Khóa 1 (hình) — thay toàn bộ bằng bộ chuẩn chung của Mưa

Theo trả lời của Đạo diễn ca 17:33 ngày 27/11/2026 (Khóa 1 CHƯA ĐẠT vì 25 hình trong gói v1 là hình Nắng tự vẽ, không phải bộ Mưa đã duyệt), Nắng thay toàn bộ 25 hình bằng bộ hình chuẩn trưởng thành của Mưa tại `MUA/MUA_M3_TAP1_HINH_CHUAN_TRUONG_THANH_2711.zip` (5.897.961 byte, MD5 ecd411c8fd6553844d2367ca7b222289, đã duyệt 17:29). Từ nay phim Tập 3 dùng bộ này, không vẽ lại.

Bảng đối chiếu thay file (cũ trong v1 → mới trong v2, thư mục `khoa-khung-hinh/`):

| # | File cũ (v1, tự vẽ) | File mới (v2, bộ Mưa đã duyệt) |
|---|---|---|
| 1 | 01-ti.webp | TI_TRUONG_THANH.webp |
| 2 | 02-bac-re.webp | BAC_RE_TRUONG_THANH.webp |
| 3 | 03-chi-la.webp | CHI_LA_TRUONG_THANH.webp |
| 4 | 04-sau-xanh.webp | SAU_XANH_TRUONG_THANH.webp |
| 5 | 05-giun-dat.webp | GIUN_DAT_TRUONG_THANH.webp |
| 6 | 06-ong-mat-troi.webp | ONG_MAT_TROI_TRUONG_THANH.webp |
| 7 | 07-chi-may.webp | CHI_MAY_TRUONG_THANH.webp |
| 8 | 08-ca-nho.webp | CA_NHO_TRUONG_THANH.webp |
| 9 | 09-rua-bien.webp | RUA_BIEN_TRUONG_THANH.webp |
| 10 | 10-khi-con.webp | KHI_CON_TRUONG_THANH.webp |
| 11 | 11-ngua-con.webp | NGUA_TRUONG_THANH.webp |
| 12 | 12-son-duong.webp | SON_DUONG_TRUONG_THANH.webp |
| 13 | 13-lac-da.webp | LAC_DA_TRUONG_THANH.webp |
| 14 | 14-chim-canh-cut.webp | CANH_CUT_TRUONG_THANH.webp |
| 15 | 15-bo-canh-cung.webp | BO_CANH_CUNG_TRUONG_THANH.webp |
| 16 | 16-cao-tuyet.webp | CAO_TUYET_TRUONG_THANH.webp |
| 17 | 17-ech-cay.webp | ECH_CAY_TRUONG_THANH.webp |
| 18 | 18-hoa-tulip.webp | HOA_TULIP_TRUONG_THANH.webp |
| 19 | 19-ca-hoi.webp | CA_HOI_TRUONG_THANH.webp |
| 20 | 20-llama.webp | LLAMA_TRUONG_THANH.webp |
| 21 | 21-cay-o-liu.webp | CAY_O_LIU_TRUONG_THANH.webp |
| 22 | 22-cay-duoc.webp | CAY_DUOC_TRUONG_THANH.webp |
| 23 | 23-tho-ngoc.webp | THO_NGOC_TRUONG_THANH.webp |
| 24 | 24-robot.webp | ROBOT_TRUONG_THANH.webp |
| 25 | 25-tia-nang-vang.webp | TIA_NANG_VANG_TRUONG_THANH.webp |

Các phần khác trong gói giữ nguyên bản v1 đã duyệt: Khóa 2 giọng mẫu (24 wav + pace-mau-giong.txt, ĐẠT) và Khóa 3 animatic + bản chuẩn bị clip + kich-ban-thoai-mua3-tap3.txt (ĐẠT). Tham chiếu ảnh trong animatic/prep (ghi theo tên cũ 01–25) ánh xạ 1–1 theo bảng trên, theo tên nhân vật.
